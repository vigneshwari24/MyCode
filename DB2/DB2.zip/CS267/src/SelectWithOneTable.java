import java.util.*;

public class SelectWithOneTable {
	ArrayList<String> LHS; 		
	ArrayList<String> operator;
	ArrayList<String> RHS;		
	ArrayList<String> logical; 
	ArrayList<Boolean> isLiteral;
	ArrayList<Predicate> predicates;
	Boolean mLiteral = false;
	boolean wo = false;
	public void select(ArrayList<String> sqlarray, Table t) {
		boolean orderBy = sqlarray.contains("ORDER");
		boolean where = sqlarray.contains("WHERE");
		if(!where && orderBy) {
			nowhereOrderby(sqlarray, t);
			return;
		}
		else if(!orderBy && where) {
			wherenoOrderby(sqlarray, t);
			return;
		} else  if(orderBy && where) {
			wo = true;
			whereOrderby(sqlarray, t);
			return;
		}
	}
private boolean getLiteralEquivalent(String LHS,String RHS, String Operator)
{
	//System.out.println("GetLiteraEquivalent +" + LHS + " " + RHS + " "+Operator);
	//System.out.println("GetLiteraEquivalent -");
	boolean bRet = false;
	switch(Operator)
	{
		case "=":
		case "==":
		bRet = ((LHS.equals(RHS)));			
		break;
		case ">=":
		bRet = (Integer.parseInt(LHS) >= Integer.parseInt(RHS));
		break;
		case "<=":
		bRet = (Integer.parseInt(LHS) <= Integer.parseInt(RHS));
		break;
		case ">":
		bRet = (Integer.parseInt(LHS) > Integer.parseInt(RHS));
		break;
		case "!=":
		bRet = ((!LHS.equals(RHS)));
		break;
		case "<":
		bRet = (Integer.parseInt(LHS) < Integer.parseInt(RHS));
		break;
	}
	//System.out.println("Result is "+bRet);
	return bRet;
	
}
private void modifySequence()
{
	//System.out.println("********************Modify sequence***********************");
	
	int Index = 0;
		
	for(Predicate pa : predicates) {
		//if(s.equals(pa.getText())) {
			//System.out.println(pa.getText() + " " +pa.getSequence());
			//break;
		//}
	}
	//calculate all the left parsing first
	for(Boolean b:isLiteral)
	{
		//System.out.println("b"+Index);
		if(isLiteral.get(Index))
		{
			if(getLiteralEquivalent(LHS.get(Index),RHS.get(Index),operator.get(Index)))
			{
				predicates.get(Index).setFf1(1);
				//System.out.println("true");
			}
			else
			{
				predicates.get(Index).setFf1(0);
			    //System.out.println("false");
			}
			//System.out.println("is Literal"+Index);
			String currentOp = (Index == 0)?logical.get(0):logical.get(Index -1);
			//System.out.println("1");
			int LogicalIndex = (Index == 0)?0:(Index -1);
			//System.out.println("2");
			predicates.get(Index).setSequence(0);
			//System.out.println("3");
			if(getLiteralEquivalent(LHS.get(Index),RHS.get(Index),operator.get(Index)))
			{			
				if(currentOp.equalsIgnoreCase("and"))
				{
					predicates.get(Index).setSequence(0);
				}
				else if(currentOp.equalsIgnoreCase("or"))
				{
					boolean bFlag = false;
					for(int i = Index - 1 ; i >= 0 ; i--) // parse the left side
					{
						
						currentOp = logical.get(LogicalIndex);
						if(currentOp.equalsIgnoreCase("or"))
						{
							predicates.get(i).setSequence(0);
							
						}
						else
						{
							bFlag = true;
							break;
						}
						LogicalIndex--;
					}			
					
					if(!bFlag && Index +1 != isLiteral.size())// parse the righ hand side
					{
						
						for(int i = Index + 1; i < isLiteral.size();i++)
						{
							currentOp = logical.get(i -1);
							if(currentOp.equalsIgnoreCase("or"))
							{
								predicates.get(i).setSequence(0);
							
							}
							else
							{
							//	bFlag = true;
								break;
							}
						}
					}						
				}
			}
			else
			{
				if(currentOp.equalsIgnoreCase("and"))
				{
					boolean bFlag = false;
					//System.out.println("Test1");
					for(int i = Index - 1 ; i >= 0 ; i--) // parse the left side
					{
						
						currentOp = logical.get(LogicalIndex);
						if(currentOp.equalsIgnoreCase("and"))
						{
							predicates.get(i).setSequence(0);
							
						}
						else
						{
							bFlag = true;
							break;
						}
						LogicalIndex--;
					}			
					//System.out.println("Test2");
					if(!bFlag && Index +1 != isLiteral.size())// parse the righ hand side
					{
						
						for(int i = Index + 1; i < isLiteral.size();i++)
						{
							currentOp = logical.get(i -1 );
							if(currentOp.equalsIgnoreCase("and"))
							{
								predicates.get(i).setSequence(0);
							
							}
							else
							{
							//	bFlag = true;
								break;
							}
						}
					}
				}
				else if(currentOp.equalsIgnoreCase("or"))
				{
					predicates.get(Index).setSequence(0);	
				}
			}
			
		}		
		Index++;
	}
	ArrayList<Integer> seqval = new ArrayList<Integer>();
	for(Predicate pa : predicates) 
	{
		if(pa.getSequence() != 0)
			seqval.add(pa.getSequence());
		
	}
	Collections.sort(seqval);
	//System.out.println("-------------------seqval in ascending order------");
	//for(int pa : seqval) 
	{
		//System.out.println(seqval);	
		
	}
	/*int minSeq = predicates.get(0).getSequence();
	for(Predicate pa : predicates) 
	{
		if(minSeq == 0)
			minSeq = pa.getSequence();
		if(minSeq > pa.getSequence() && pa.getSequence() != 0)
			minSeq = pa.getSequence();
	}
	if(minSeq != 0)
	{
		int i = minSeq , j = 1;
		for(Predicate pa : predicates) 
		{
			if(pa.getSequence() == i)
			{
				pa.setSequence(j);
				j++;
				i++;
			}
		}
	}*/
	int j = 1, i = 0;
	for(int p : seqval)
	{
		i = p;
		for(Predicate pa : predicates)
		{
			if(pa.getSequence() == i)
			{
				pa.setSequence(j);
				
			}
		}	
		j++;
		//i++;
	}
	
}
private boolean isColumn(String CheckVar,Table t)
{
	boolean bRet = false;
	for(Column c: t.getColumns())
	{
		int index = CheckVar.indexOf(".");
		//System.out.println(c.getColName() + " "+ CheckVar);
		if(c.getColName().equalsIgnoreCase(CheckVar.substring(index+1))) 
		{
			bRet = true;
			
			break;
		}
	}
	return bRet;
}
private int CheckForConflict(int i,int j,Table t)
{
	boolean bCheck = false;
	switch(operator.get(i))
	{
		case ">":
			if(operator.get(j).equalsIgnoreCase(">"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(logical.get(j-1).equalsIgnoreCase("or"))
				{
					if(rhs1 > rhs2)
						predicates.get(i).setSequence(0);
					else
						predicates.get(j).setSequence(0);
				}
				else
				{
					if(rhs1 > rhs2)
						predicates.get(j).setSequence(0);
					else
						predicates.get(i).setSequence(0);
				}
			}
			else if(operator.get(j).equalsIgnoreCase("<"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				//System.out.println("************> < Conflict******");
				if(rhs1 == rhs2)
				{
					if(logical.get(j-1).equalsIgnoreCase("or"))
						return 1;
					else if(logical.get(j-1).equalsIgnoreCase("and"))
						return -1;
				}
			}
			else if(operator.get(j).equalsIgnoreCase("="))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 < rhs1)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
					   return -1;
				}	
				else
					predicates.get(i).setSequence(0);
			}
		break;
		case "<":
			if(operator.get(j).equalsIgnoreCase(">"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				
				if(rhs1 == rhs2)
				{
					if(logical.get(j-1).equalsIgnoreCase("or"))
						return 1;
					else if(logical.get(j-1).equalsIgnoreCase("and"))
						return -1;
				}
			}
			else if(operator.get(j).equalsIgnoreCase("<"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(logical.get(j-1).equalsIgnoreCase("or"))
				{
					if(rhs1 > rhs2)
						predicates.get(j).setSequence(0);
					else
						predicates.get(i).setSequence(0);
				}
				else
				{
					if(rhs1 > rhs2)
						predicates.get(i).setSequence(0);
					else
						predicates.get(j).setSequence(0);
				}
				return 0;
			}
			else if(operator.get(j).equalsIgnoreCase("="))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 > rhs1)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
					   return -1;
				}
				else
					predicates.get(i).setSequence(0);
			}
		break;
		case "=":
			if(operator.get(j).equalsIgnoreCase(">"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 > rhs1)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
					   return -1;
				}	
				else
					predicates.get(j).setSequence(0);
			}
			else if(operator.get(j).equalsIgnoreCase("<"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 > rhs1)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
					   return -1;
				}
				else
					predicates.get(i).setSequence(0);
				return 0;
			}
			else if(operator.get(j).equalsIgnoreCase("!="))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				
				if(rhs1 == rhs2)
				{
					if(logical.get(j-1).equalsIgnoreCase("or"))
						return 1;
					else if(logical.get(j-1).equalsIgnoreCase("and"))
						return -1;
				}
			}
			else if(operator.get(j).equalsIgnoreCase("="))
			{
				//System.out.println("************Conflict******");
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				//System.out.println("rhs1 != rhs2");
				if(rhs1 != rhs2)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
						return -1;
				}
			}
		break;
		case "!=":
			if(operator.get(j).equalsIgnoreCase(">"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 > rhs1)
				{
					predicates.get(i).setSequence(0);
				}					
			}
			else if(operator.get(j).equalsIgnoreCase("<"))
			{
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs2 < rhs1)
				{
					predicates.get(i).setSequence(0);
				}	
				return 0;
			}
			else if(operator.get(j).equalsIgnoreCase("!="))
			{
				//System.out.println("************Conflict******");
				if(isColumn(RHS.get(i),t) || isColumn(RHS.get(j),t))
				{
					return 0;
				}
				int rhs1 = Integer.parseInt(RHS.get(i));
				int rhs2 = Integer.parseInt(RHS.get(j));
				if(rhs1 != rhs2)
				{
					if(logical.get(j-1).equalsIgnoreCase("and"))
						return -1;
				}
			}
			else if(operator.get(j).equalsIgnoreCase("="))
			{

			}
		break;
		default: 
		break;
	}
	return 0;
}
private void ProcessConflictingPredicates(Table t) 
{
	String CurrentOp;
	boolean isConflict = false;
	int i = 0 , j = 0 , k = 0;
	for( i = 0; i <  LHS.size()- 1; i++)
	{	
		CurrentOp = logical.get(i);	
		isConflict = false;
		for( j = i+1 ; j< LHS.size();j++)
		{
			//System.out.println(CurrentOp + " " + logical.get(j-1));
			if(CurrentOp.equalsIgnoreCase(logical.get(j-1)))
			{
				if(LHS.get(i).equalsIgnoreCase(LHS.get(j)))
				{
					int retval = CheckForConflict(i,j,t);
					if(retval != 0)
						isConflict = true;
				}
			}		
			else
			{
				//System.out.println("break");
				break;
			}
		}
		if(isConflict)
		{
			//System.out.println("*******is conflict******** " + i + " " + j);
			/*if(j < LHS.size())
			{
				j = j + 1;
			}*/
			for( k = i ; k < j; k++)
				predicates.get(k).setSequence(0);
		}
	}
	ArrayList<Integer> seqval = new ArrayList<Integer>();
	for(Predicate pa : predicates) 
	{
		if(pa.getSequence() != 0)
			seqval.add(pa.getSequence());
		
	}
	Collections.sort(seqval);
	//System.out.println("-------------------seqval in ascending order------");
	//for(int pa : seqval) 
	{
		//System.out.println(seqval);	
		
	}
	j = 1; i = 0;
	for(int p : seqval)
	{
		i = p;
		for(Predicate pa : predicates)
		{
			if(pa.getSequence() == i)
			{
				pa.setSequence(j);
				
			}
		}	
		j++;
		//i++;
	}
	
}
private void removeLiterals()
{
	int index = 0;
	
	//System.out.println("before removing unnecessary variables");
	//System.out.println("LHS:"+LHS);
	//System.out.println("isLiteral size:" + isLiteral.size()+isLiteral);
	//System.out.println("size:");
	//System.out.println("Logical:"+logical);
	//System.out.println("Operator"+operator);
	//System.out.println("RHS:"+RHS);
	for(Boolean b:isLiteral)
	{
		if(b)
		{
			//System.out.println("[1]"+index+LHS.get(index));
//			getLiteralEquivalent(LHS.get(index),RHS.get(index),operator.get(index));
			LHS.remove(index);
			//System.out.println("[1.1]");
			operator.remove(index);
			//System.out.println("[1.2]");
			RHS.remove(index);
			
			//System.out.println("[2]");
			if(index == 0)
				logical.remove(0);
			else
				logical.remove(index -1);
			index--;
			//System.out.println("[3]");
		}
		index++;
	}
	//System.out.println("after removing unnecessary variables");
	//System.out.println("LHS:"+LHS);
	//System.out.println("size:"+LHS.size());
	//System.out.println("Logical:"+logical);
	//System.out.println("Operator"+operator);
	//System.out.println("RHS:"+RHS);

}
private void ProcessLiterals(Table t)
{
	//System.out.println("++++++++++++++++");
	Predicate p = new Predicate();
	
	
	isLiteral = new ArrayList<Boolean>();
	boolean bLiteral = true;
	for(String s: LHS)
	{
		bLiteral = true;
		for(Column c: t.getColumns())
		{
			int index = s.indexOf(".");
			//System.out.println(c.getColName() + " "+ s);
			if(c.getColName().equalsIgnoreCase(s.substring(index+1))) 
			{
				bLiteral = false;
				
				break;
			}
		}
		if(bLiteral)
		{
			mLiteral = true;
			//System.out.println("*****************Literal is present******************");
			
		}
		isLiteral.add(bLiteral);
	} 
	//remove
	//System.out.println("--------------------------");
	//System.out.println("After Processing Literals "+isLiteral);
	
	
	//return p;
}
 
 private void whereOrderby(ArrayList<String> sqlarray, Table t) {
		PlanTable p = new PlanTable();
		p.queryBlockNo = 1;
		p.sortC_orderBy = 'N';
		p.table1Card = t.getTableCard();
		LHS = new ArrayList<String>();
		operator = new ArrayList<String>();
		RHS = new ArrayList<String>();
		logical = new ArrayList<String>();
		int endindex = sqlarray.size() - 1;
		int andorCounter = 0;
		int orCounter = 0;
		ArrayList<String> intermediate = new ArrayList<String> ();
			for(int i = sqlarray.indexOf("WHERE") + 1; i <= endindex; i++) {
				if(sqlarray.get(i).equals("AND") || sqlarray.get(i).equals("OR")) {
					andorCounter++; 
					if(sqlarray.get(i).equals("OR")) orCounter++; //for in list transformation
				} 
				intermediate.add(sqlarray.get(i));
			}
			ArrayList<Integer> andorindex = new ArrayList<Integer>();
			int in = 0;
			//System.out.println(intermediate + " intermediate");
			for(String s: intermediate) {
				if(s.equals("AND") || s.equals("OR")) {
					andorindex.add(in);
					logical.add(s);
				}	
				in++;
			}
			//System.out.println(andorindex + " andorindex");
			int index = 0;
			for(int i = 0; i < intermediate.size(); i++ ) {
				LHS.add(intermediate.get(i));
				operator.add(intermediate.get(i + 1));
				StringBuffer sb = new StringBuffer();
				if(andorCounter > 0) {
					int a = i + 2;
					for(; a < andorindex.get(index); a++) {
						sb.append(intermediate.get(a));
					}
					RHS.add(sb.toString());
					index++;
					andorCounter--;
					i = a;
				} else {
					int a = i + 2;
					for(; a < intermediate.size(); a++) {
						sb.append(intermediate.get(a));
					}
					RHS.add(sb.toString());
					i = a;
					}
			}
		
			/*
			 * In list transformation code
			 */
			boolean textdescriptionflag = false;
			if(orCounter == LHS.size() - 1) {
				Set<String> s = new HashSet<String>();
				for(String lh : LHS) 
					s.add(lh);
				Set<String> oper = new HashSet<String> ();
				for(String op: operator) {
					oper.add(op); // to check for equal sign
				}
				//System.out.println(oper + " oper");
				if(oper.size() == 1 && oper.contains("=")) 
				if(s.size() == 1 && andorindex.size() > 0) {
					textdescriptionflag = true;
					LHS = new ArrayList<String> ();
					LHS.add((String)s.toArray()[0]);
					operator = new ArrayList<String> ();
					operator.add("IN");
					StringBuffer sb = new StringBuffer();
					for(String rhs: RHS) {
						sb.append(rhs).append(" ").append(", ");
					}
				String rhs = "( ".concat(sb.toString().substring(0 , sb.toString().length() - 2)).concat(" )");
				RHS = new ArrayList<String> ();
				RHS.add(rhs);
				logical = new ArrayList<String>();
				}
				
			}
		//System.out.println(LHS + " LHS");
		//System.out.println(operator+ " operator");
		//System.out.println(RHS + " RHS");
		//System.out.println(logical+ " logical");
		ProcessLiterals(t);
		predicates = new ArrayList<Predicate>();
		int cnt = 0;
		for(String s: LHS){
			Predicate predicate = new Predicate();
			int indexOfDot = s.indexOf(".");
			String lhsname = s.substring(indexOfDot+1);
			Column c = null;
		if(isLiteral.get(cnt))
		{
			switch(operator.get(cnt)) 
			{
				case "=":
				predicate.setType('E');
				break;
				case "IN":
				predicate.setType('I');
				break;
				default:
				predicate.setType('R');
				break;
			}
			predicate.setText(s.concat(operator.get(cnt)).concat(RHS.get(cnt)));
			predicate.setFf1(11111);
			
		}
		else
		{
			for(Column col: t.getColumns()) {
				//System.out.println("COL LOOP " + col.getColName());
				if (col.getColName().equalsIgnoreCase(lhsname)) {
					c = col;
					break;
				}
			}
			//System.out.println(" cols ck pt  " + lhsname);
			//System.out.println("COLS CK PT " + c );
			switch(operator.get(cnt)) {
			case "=": 
				predicate.setCard1(c.getColCard());
				predicate.setFf1(1/new Double(c.getColCard()));
				predicate.setType('E');
				predicate.setText(s.concat(" = ").concat(RHS.get(cnt)));
				break;
			case "IN": 
				predicate.setCard1(c.getColCard());
				predicate.setType('I');
				String pred [] = RHS.get(cnt).split(",");
				int noofcols = pred.length;
				if(textdescriptionflag) {
					predicate.setFf1(noofcols/new Double(c.getColCard()));
					predicate.setDescription(s.concat(" IN ").concat(RHS.get(cnt)));
					StringBuffer sb = new StringBuffer();
					String array []  = RHS.get(0).split(" ");
					for(String arr: array) {
						//System.out.println(arr + " in loop");
						if (arr.trim().length() != 0 && arr.trim().equals("(") == false && arr.trim().equals(",") == false && arr.trim().equals(")") == false) {
							////System.out.println(arr + " in if");
							sb.append(LHS.get(0)).append(" = "+arr + " OR ");
						}
					}
					//System.out.println(sb.toString().substring(0, sb.toString().length() - 3) + " sysoVIK");
					predicate.setText(sb.toString().substring(0, sb.toString().length() - 3));
				} else {
					if(noofcols > 1) {
						predicate.setFf1(noofcols/new Double(c.getColCard()));
					} else {
						predicate.setType('E');
						predicate.setFf1(1.0/new Double(c.getColCard()));
						predicate.setText(s.concat(" IN ").concat(RHS.get(cnt)));
						int indexofopen = pred[0].indexOf('(');
						int indexofclose = pred[0].indexOf(')');
						predicate.setDescription(s.concat(" = ").concat(pred[0].substring(indexofopen + 1, indexofclose).trim()));
					}
					predicate.setText(s.concat(" IN ").concat(RHS.get(cnt)));
				}
				
				break;
			default: 
				predicate.setCard1(c.getColCard());
				predicate.setType('R');
				predicate.setText(s.concat(" ").concat(operator.get(cnt) + " ").concat(RHS.get(cnt)));
				Column.ColType colType = c.getColType();
				String hikey = c.getHiKey().toUpperCase();
				String lokey = c.getLoKey().toUpperCase();
				if(operator.get(cnt).charAt(0)=='<') {
					if(colType.toString().equals("CHAR")) {
						hikey = hikey.substring(0, 2);
						lokey = lokey.substring(0, 2);
						double hikeyI = ((hikey.charAt(0)-64)* 26 + (hikey.charAt(1)-64)*1);
						double lokeyI = ((lokey.charAt(0)-64)* 26 + (lokey.charAt(1)-64)*1);
						double literal = ((RHS.get(cnt).charAt(0)-64)* 26 + (RHS.get(cnt).charAt(1)-64)*1);
						double ff = (literal - lokeyI) / new Double(hikeyI - lokeyI);
						predicate.setFf1(ff);
					} else {
						//System.out.println(colType);
						//System.out.println("IN INT");
						double hikeyI = Integer.parseInt(hikey);
						double lokeyI = Integer.parseInt(lokey);
						double literal = Integer.parseInt(RHS.get(cnt));
						double ff = (literal - lokeyI) / new Double(hikeyI - lokeyI);
						predicate.setFf1(ff);
					}
				} else {
					if(colType.toString().equals("CHAR")) {
						hikey = hikey.substring(0, 2);
						lokey = lokey.substring(0, 2);
						int hikeyI = ((hikey.charAt(0)-64)* 26 + (hikey.charAt(1)-64)*1);
						int lokeyI = ((lokey.charAt(0)-64)* 26 + (lokey.charAt(1)-64)*1);
						int literal = ((RHS.get(cnt).charAt(0)-64)* 26 + (RHS.get(cnt).charAt(1)-64)*1);
						double ff = (hikeyI - literal) / new Double (hikeyI - lokeyI);
						predicate.setFf1(ff);
					} else {
						int hikeyI = Integer.parseInt(hikey);
						int lokeyI = Integer.parseInt(lokey);
						int literal = Integer.parseInt(RHS.get(cnt));
						double ff = (hikeyI - literal) / new Double(hikeyI - lokeyI);
						predicate.setFf1(ff);
					}
				}
				break;
		}
			}
			predicates.add(predicate);
			cnt++;
		}
		Map<Double, String> result = new HashMap<Double, String> ();
		for(Predicate p1 : predicates) {
			result.put(p1.getFf1(), p1.getText());
		}
		Map<Double,String> r = new TreeMap<Double,String> (result);
		ArrayList<Integer> seqval= new ArrayList<Integer>();
		ArrayList<String> labl = new ArrayList<String> ();
	int count = 1,indx = 0;
		for (Map.Entry<Double, String> entry : r.entrySet())
		{
		    //System.out.println(entry.getKey() + "/" + entry.getValue());
		    seqval.add(count++);
		    labl.add(entry.getValue());
		}
		//System.out.println(seqval);
		//System.out.println(labl);
		int index1 = 0;
		for (String s : labl)
		for(Predicate pa : predicates) {
			if(s.equals(pa.getText())) {
				pa.setSequence(seqval.get(index1++));
				break;
			}
		}
		if(mLiteral)
			modifySequence();
		removeLiterals();
	
		ProcessConflictingPredicates(t);
		ArrayList<Integer> lhsid = new ArrayList<Integer>();
		for(String s: LHS) { 
			int index11 = s.indexOf(".");
			for(Column c: t.getColumns()) {
				if(c.getColName().equalsIgnoreCase(s.substring(index11+1))) {
					lhsid.add(c.getColId());
					break;
				}
		}
		}//System.out.println("lhsid " + lhsid);
		String tempidxname = "";
		int x = 0;
		ArrayList<String> lhsidxname = new ArrayList<String> ();
		ArrayList<Integer> lhsidxcol = new ArrayList<Integer>();
		for(int a : lhsid) {
			boolean noindexfound = true;
			tempidxname = "";
			x = t.getNumColumns() + 1;
		for(Index id: t.getIndexes()) {
			for(Index.IndexKeyDef ikd : id.getIdxKey()) {
				if(a == ikd.colId) {
						if(ikd.idxColPos < x) {
							x = ikd.idxColPos;
							tempidxname = id.getIdxName();
							noindexfound = false;
							break;
						}
					}
				}
			}
		if(!noindexfound) {
			lhsidxname.add(tempidxname); 
			lhsidxcol.add(x);
		}
		else {lhsidxname.add("NOINDEX");
		lhsidxcol.add(-1);
		 }
		}
		//System.out.println(lhsidxname);
		//System.out.println(lhsidxcol);
		//System.out.println(LHS);
		//System.out.println(lhsid);
		new Predicate().printTable(new DbmsPrinter(), predicates);
		//System.out.println("*******CHECK POINT*************");
		//System.out.println(LHS + " LHS");
		//System.out.println(operator+ " operator");
		//System.out.println(RHS + " RHS");
		//System.out.println(logical+ " logical");
		ArrayList<String> columnList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i).split("\\.")[1]);
			}
		}
		//System.out.println(columnList + " colslist");
		//column list extraction end
		if(logical.contains("OR")) {
			p.accessType = 'R';
			p.prefetch = 'S';
			//work on predicates --done
				
		} else if(sqlarray.contains("AND") || andorindex.size() == 0) { //contains only AND
			ArrayList<String> lhswodot = new ArrayList<String> ();
				for(String s: LHS) {
					lhswodot.add(s.substring(s.indexOf('.') + 1));
				}
				//System.out.println(lhswodot + " lhswo.");
				//System.out.println(columnList);
				ArrayList<Integer> columnListIndex = new ArrayList<Integer> ();
				for(String s: lhswodot) {
					for(Column c: t.getColumns()) {
						if(c.getColName().trim().equalsIgnoreCase(s.trim())) {
							columnListIndex.add(c.getColId());
							break; //handle LITERAL
						}
					}
				}
				//System.out.println(columnListIndex + " columnListIndex");
				ArrayList<String> ind = new ArrayList<String> ();
				ArrayList<ArrayList <Integer>> indval = new ArrayList<ArrayList<Integer>> (); 
				//extract available columns n index
				Set<Integer> colsavinindex = new HashSet<Integer> ();
				for(Index i: t.getIndexes()) {
					ind.add(i.getIdxName());
					ArrayList<Integer> rem = new ArrayList<Integer> ();
					for(Index.IndexKeyDef ikd: i.getIdxKey()) {
						rem.add(ikd.colId);
						colsavinindex.add(ikd.colId);
					}
					indval.add(rem);
				}
				ArrayList<Integer> columnListIndexrep = new ArrayList<Integer>();
				for(int coas: columnListIndex) {
					if(colsavinindex.contains(coas)) {
						columnListIndexrep.add(coas);
					}
				}
				//System.out.println(ind + "ind <-- index name");
				//System.out.println(indval + " INDVALLL");
				ArrayList<ArrayList<String>> mat = new ArrayList<ArrayList<String>> ();
				//System.out.println(colsavinindex + " colsin index set");
				boolean containsR = operator.contains(">") || operator.contains(">=") || operator.contains("<") || operator.contains("<=");
				//System.out.println(columnListIndex+ " F###");
				if(!containsR) {
				for(ArrayList<Integer> ai: indval) { //array of array 
					ArrayList<String> temp = new ArrayList<String> ();
					for(int i = 0; i < ai.size(); i++) {
						if (columnListIndexrep.contains(ai.get(i))) {
							if(i == 0) {
								temp.add("M");
							} else {
								if(temp.get(i - 1).equals("M")) {
									temp.add("M");
								} else temp.add("S");
							}
						} else {
							temp.add("N");
						}
					}
					mat.add(temp);
				} } else { //handle range
					for(ArrayList<Integer> ai: indval) { //array of array 
						ArrayList<String> temp = new ArrayList<String> ();
						//System.out.println(ai + " ai");
						//int j = -1;
						
						for(int i = 0; i < ai.size(); i++) {
							//j++;
							//System.out.println("IN RANGE CHK outside else");
							//System.out.println(operator);
							//System.out.println(columnListIndex);
							//System.out.println(columnListIndexrep);
							//System.out.println(lhsid);
							if (columnListIndexrep.contains(ai.get(i))) {
								////System.out.println("INDEX CK");
								////System.out.println(columnListIndexrep.indexOf(ai.get(j)) + " gg "+ ai.get(i));
								if(i == 0) {
									temp.add("M");
								} else {
									//System.out.println("IN RANGE CHK");
									if(operator.get(i - 1).trim().charAt(0) == '<' || operator.get(i - 1).trim().charAt(0) == '>') {
										temp.add("M");
									} else {
										temp.add("S");
									}
								}
							} else {
								temp.add("N");
							}
						}
						mat.add(temp);
					}
				}
				//System.out.println(mat + " mat");
				ArrayList<Integer> msn = new ArrayList<Integer>();
				int m = 0, s = 0;
				
				for(ArrayList<String> ai: mat) {
					m = 0;
					s = 0;
					for(String snm: ai) {
						if(snm.equals("M")) {
							m++; 
						} else if(snm.equals("S")) {
							s++;
						}
					}
					msn.add(Integer.parseInt(new String(""+m+s)));
				}
				//System.out.println(msn + " msn");
				int X = 0;
				int target = 0;
				String accName = "";
				for(int tar: msn) {
					//System.out.println(target + " targ" + tar + " tar");
					if(target < tar) {
						//System.out.println("n if");
						target = tar;
						accName = ind.get(X);
						////System.out.println(X + " X");
					}
					X++;
				}
				/*
				 * tie breaker code
				 */
				ArrayList<ArrayList<String>> matMatch = new ArrayList<ArrayList<String>> ();
				ArrayList<Integer> tiebreaker = new ArrayList<Integer> ();
				ArrayList<String> indMatch = new ArrayList<String> ();
				ArrayList<ArrayList<Integer>> indvalMatch = new ArrayList<ArrayList<Integer>> ();
				X = 0;
				for(int tie: msn) {
					if(target == tie) {
						tiebreaker.add(target);
						if(mat.get(X).contains("M") || mat.get(X).contains("S")) {
							matMatch.add(mat.get(X));
							indMatch.add(ind.get(X));
							indvalMatch.add(indval.get(X));
						}
						
					}
					X++;
				}
				//if(tiebreaker.size() > 1) {
				//System.out.println(ind + " ind tiebreaker code");
				//System.out.println(mat + " mat");
				//System.out.println(indval + " indval");
				//System.out.println(tiebreaker + " tiebreaker");
				//System.out.println(matMatch + " matMatch");
				//System.out.println(indMatch + " indMatch");
				//System.out.println(indvalMatch  + " indvalMatch");
				
				boolean tiebreaker1 = false;
				X = 0;
				ArrayList<Integer> fftie =  new ArrayList<Integer> ();
				ArrayList<String> fftieindex = new ArrayList<String>();
				if(matMatch.size() > 1) {
					X = 0;
					int countOfMS = 0;
					boolean mflag = false;
					
					for(String st: matMatch.get(0)) {
						if(st.equals("M") || st.equals("S")) {
							countOfMS++;
							if(st.equals("M")) {
								mflag = true;
							}
						}
					}
					ArrayList<Double> ffarr = new ArrayList<Double> ();
					ArrayList<String> ffarrcolind = new ArrayList<String>();
					
					if(countOfMS == 1) {
						X = 0;
						int indofms = 0;
						for(ArrayList<String> as : matMatch) {
							if(mflag) {
								indofms = as.indexOf("M");
							}else {
								indofms = as.indexOf("S");
							}
								int colid = indvalMatch.get(X).get(indofms);
								ffarrcolind.add(indMatch.get(X));
								String colname = "";
								for(Column c: t.getColumns()) {
									if(c.getColId() == colid) {
										colname = c.getColName();
										break;
									}
								}
								for(Predicate per : predicates) {
									if(per.text.toLowerCase().contains(colname.toLowerCase())) {
										ffarr.add(per.ff1);
										//System.out.println("In for " + per.text);
									}
								}
							X++;
						}
						//System.out.println(ffarr + " ffarr count = 1");
						//System.out.println(ffarrcolind);
						//System.out.println();
					} else {
						X = 0;
						for(ArrayList<String> as : matMatch) {
							int inds = 0;
							ArrayList<Integer> coli = new ArrayList<Integer>();
							ArrayList<String> coln = new ArrayList<String> ();
							ArrayList<Double> ffa = new ArrayList<Double> ();
							for(String st: as ) {
								if(st.equals("M") || st.equals("S")) {
									coli.add(indvalMatch.get(X).get(inds));
								}
								inds++;
							}
							for(int colid: coli)
							for(Column c: t.getColumns()) {
								if(c.getColId() == colid) {
									coln.add(c.getColName()); break;
								}
							}
							double pred = 1.0;
							for(String colname: coln)
							for(Predicate per : predicates) {
								if(per.text.toLowerCase().contains(colname.toLowerCase())) {
									ffa.add(per.ff1);
									//System.out.println("In for " + per.text);
								}
							}
							for(Double d: ffa) {
								pred *= d;
							}
							ffarr.add(pred);
							ffarrcolind.add(indMatch.get(X));
							X++;
						}
					}
					double min = ffarr.get(0);
					X = 0;
					
					for(Double doub : ffarr) {
						if(doub < min) {
							min = doub;
							accName = ffarrcolind.get(X);
						}
						X++;
					}
					tiebreaker1 = true;
					p.accessName = accName;
				}
				
				//System.out.println("FFFFFFFFFFFFFF");
				//System.out.println(fftie);
				//System.out.println(fftieindex);
				ArrayList<String> ffcolname = new ArrayList<String> ();
				ArrayList<Double> ff = new ArrayList<Double> ();
				for(int i : fftie) {
					for(Column cc: t.getColumns()) {
						if(cc.getColId() == i) {
							ffcolname.add(cc.getColName());
							break;
						}
					}
				}
				//System.out.println(ffcolname + " ffcolname");
				for(String ffc : ffcolname)
				for(Predicate pr : predicates) {
					if(pr.text.toLowerCase().contains(ffc.toLowerCase())) {
						//System.out.println(ffc + " "  + pr.ff1);
						ff.add(pr.ff1);
						break;
					}
				}
				X = 0;
				double ffti = 10.0;
				String accN = "5";
				for(int i = 0; i < ff.size(); i++) {
					//System.out.println(ff.get(i));
					if(ff.get(i) < ffti) {
						//System.out.println("Inside if");
						ffti = ff.get(i);
						accN = fftieindex.get(i);
					}
				}
				//System.out.println(accN);
				//System.out.println("accName test " + accName);
				//}
				/*
				 * tie breaker code end 
				 */
				/*if(tiebreaker.size() > 1) {
					if(fftie.size() > 1) p.accessName = accN;
					else p.accessName = indexNmae;
					//System.out.println(p.accessName + " end oftie");
					
				}*/
				//System.out.println("CHK PT target " + target);
				p.accessName = accName;
				if(target != 0) {
					if(!tiebreaker1)
					p.accessName = accName;
					String sat = ""+target;
					if(sat.length() < 2) {
						p.matchCols = 0;
					}
					else {
						
						p.matchCols = Integer.parseInt(new Character(sat.charAt(0)).toString());
					}
					
					p.prefetch = ' ';
					p.sortC_orderBy = 'N';
					p.table1Card = t.getTableCard();
					boolean flag = false;
					if(operator.contains("IN")) {
						int nd = operator.indexOf("IN");
						//columnListIndex
						int col = columnListIndex.get(nd);
						for(Index I : t.getIndexes()) {
							if(I.getIdxName().trim().equalsIgnoreCase(accName.trim())) {
								for(Index.IndexKeyDef ikd: I.getIdxKey()) {
									if(ikd.colId == col) {
										////System.out.println(RHS.get(nd).split(",").length + " RHS");
										if(RHS.get(nd).split(",").length > 1) {
											flag = true;
											break;
										}
									}
								}
							}
						}
						
					}
					if(flag) {
						p.accessType = 'N';
					} else {
						p.accessType = 'I';
					}
					
				}
				//System.out.println(columnList + " columnList");
				ArrayList<Integer> colListInt = new ArrayList<Integer> ();
				for(String co: columnList) {
					for(Column c: t.getColumns()) {
						if(c.getColName().trim().equalsIgnoreCase(co.trim())) {
							colListInt.add(c.getColId());
							break;
						}
					}
				}
				//System.out.println(colListInt + " colListInt");
				//System.out.println(colsavinindex + " colsavinindex");
				boolean indexonlyflag = true;
				for(int inte: colListInt) {
					if(!colsavinindex.contains(inte)) {
						indexonlyflag = false;
						break;
					}
				}
				boolean indexonlyFP = true;
				for(int inte: columnListIndex) {
					if(!colsavinindex.contains(inte)) {
						indexonlyFP = false;
						break;
					} else {
					}
				}
				if(indexonlyflag && indexonlyFP)
				p.indexOnly = 'Y';
				if(p.accessType == 'R') p.prefetch = 'S';
				ArrayList<Boolean> colex = new ArrayList<Boolean>();
				ArrayList<Integer> selectlist = new ArrayList<Integer> ();
				for(String col: columnList) {
					for(Column c: t.getColumns()) {
						if(col.trim().equalsIgnoreCase(c.getColName().trim())) {
							selectlist.add(c.getColId());
							break;
						}
					}
				}
				//System.out.println(selectlist);
				Index indite = null;
				for(int ai : selectlist) {
					
					for(Index inderr : t.getIndexes()) {
						if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
							indite = inderr;
							break;
						}
					}
					//ab = 0;
					if(indite != null)
					for(Index.IndexKeyDef ikd: indite.getIdxKey()) {
						if(ikd.colId == ai) {
								//ab = 1;
								colex.add(true);
						} else {
							colex.add(false);
						}
					}
					
				}
				//p.matchCols = matchcols;
				//System.out.println(colex + "CK PT");
				////System.out.println(columnListIndex + " CK PT");
				//System.out.println(columnListIndexrep + "CK PT");
				//System.out.println("CKK PT " + p.accessName);
				for(int ai : columnListIndexrep) {
					Index indiite = null;
					for(Index inderr : t.getIndexes()) {
						if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
							indiite = inderr;
							break;
						}
					}
					//ab = 0;
					if(indiite != null)
					for(Index.IndexKeyDef ikd: indiite.getIdxKey()) {
						if(ikd.colId == ai) {
								//ab = 1;
								colex.add(true);
								//matchcols++;
						} else {
							colex.add(false);
						}
					}
					//System.out.println(ai + " AI BEFORE EXIT");
				}
				//System.out.println("SELECT LIST " + selectlist);
				//System.out.println("Predicate list" + columnListIndex);
				ArrayList<Integer> indexOnlydecider = new ArrayList<Integer> ();
				for(int i : columnListIndex) {
					indexOnlydecider.add(i);	
				}
				for(int i : selectlist) {
					if(!indexOnlydecider.contains(i))
						indexOnlydecider.add(i);
				}
				
				ArrayList<Integer> indexd = null;
				if(p.accessType != 'R')
					indexd = indvalMatch.get(indMatch.indexOf(p.accessName));
				//System.out.println(indexd);
				boolean indexOnlyflag = true;
				//System.out.println("INDEXONLY DECIDER " + indexOnlydecider );
				for(int i : indexOnlydecider) {
					if(indexd!= null && !indexd.contains(i)) {
						indexOnlyflag = false;
						break;
					}
				}
				if(indexOnlyflag) {
					p.indexOnly = 'Y';
				} else {
					p.indexOnly = 'N';
				}
				if(p.accessType == 'I' || p.accessType == 'N' ) {
					if(p.accessName != null)
						if (p.accessName.trim().length() > 0)
					p.prefetch = ' ';
				}else {
					p.prefetch = 'S';
				}
			} else {
				//single predicate 
				//System.out.println("HANDLE SINGLE PREDICATE");
				//System.out.println(LHS);
				//System.out.println(RHS);
				//System.out.println(operator);
				for(Column c: t.getColumns()) {
					////System.out.println(LHS.get(0).split("\\.")[0]);
					if(c.getColName().trim().equalsIgnoreCase(LHS.get(0).split("\\.")[1])) {
						//System.out.println(c.getColId());
						break;
					}
				}
			}
		//System.out.println("IN WHERE && ORDER   ");
		//System.out.println(p.accessType);
		//System.out.println(p.accessName);
		if(p.accessType == 'R') {
			//System.out.println("WO  WO WO WO F IF ");
			nowhereOrderby(sqlarray,t);
		} else {
			//System.out.println("WO  WO WO WO ELSE ELSE ");
			//System.out.println(p.accessName);
			whereOrderByWithIndex(sqlarray, t, p.accessName , p);
		}
		//p.setAccessName(t.getTableName()+p.getAccessName());
		//p.printTable(new DbmsPrinter());
		
		
			
		}
	
private void wherenoOrderby(ArrayList<String> sqlarray, Table t) {
	PlanTable p = new PlanTable();
	p.queryBlockNo = 1;
	p.sortC_orderBy = 'N';
	p.table1Card = t.getTableCard();
	LHS 			= new ArrayList<String>();
	operator		 = new ArrayList<String>();
	RHS		 = new ArrayList<String>();
	logical 	= new ArrayList<String>();
	int endindex = sqlarray.size() - 1;
	int andorCounter = 0;
	int orCounter = 0;
	ArrayList<String> intermediate = new ArrayList<String> ();
		for(int i = sqlarray.indexOf("WHERE") + 1; i <= endindex; i++) {
			if(sqlarray.get(i).equals("AND") || sqlarray.get(i).equals("OR")) {
				andorCounter++; 
				if(sqlarray.get(i).equals("OR")) orCounter++; //for in list transformation
			} 
			intermediate.add(sqlarray.get(i));
		}
		ArrayList<Integer> andorindex = new ArrayList<Integer>();
		int in = 0;
		//System.out.println(intermediate + " intermediate");
		for(String s: intermediate) {
			if(s.equals("AND") || s.equals("OR")) {
				andorindex.add(in);
				logical.add(s);
			}	
			in++;
		}
		//System.out.println(andorindex + " andorindex");
		int index = 0;
		for(int i = 0; i < intermediate.size(); i++ ) {
			LHS.add(intermediate.get(i));
			operator.add(intermediate.get(i + 1));
			StringBuffer sb = new StringBuffer();
			if(andorCounter > 0) {
				int a = i + 2;
				for(; a < andorindex.get(index); a++) {
					sb.append(intermediate.get(a));
				}
				RHS.add(sb.toString());
				index++;
				andorCounter--;
				i = a;
			} else {
				int a = i + 2;
				for(; a < intermediate.size(); a++) {
					sb.append(intermediate.get(a));
				}
				RHS.add(sb.toString());
				i = a;
				}
		}
	
		/*
		 * In list transformation code
		 */
		boolean textdescriptionflag = false;
		if(orCounter == LHS.size() - 1) {
			Set<String> s = new HashSet<String>();
			for(String lh : LHS) 
				s.add(lh);
			Set<String> oper = new HashSet<String> ();
			for(String op: operator) {
				oper.add(op); // to check for equal sign
			}
			//System.out.println(oper + " oper");
			if(oper.size() == 1 && oper.contains("=")) 
			if(s.size() == 1 && andorindex.size() > 0) {
				textdescriptionflag = true;
				LHS = new ArrayList<String> ();
				LHS.add((String)s.toArray()[0]);
				operator = new ArrayList<String> ();
				operator.add("IN");
				StringBuffer sb = new StringBuffer();
				for(String rhs: RHS) {
					sb.append(rhs).append(" ").append(", ");
				}
			String rhs = "( ".concat(sb.toString().substring(0 , sb.toString().length() - 2)).concat(" )");
			RHS = new ArrayList<String> ();
			RHS.add(rhs);
			logical = new ArrayList<String>();
			andorindex = new ArrayList<Integer>();
			}
			
		}
	//System.out.println(LHS + " LHS");
	//System.out.println(operator+ " operator");
	//System.out.println(RHS + " RHS");
	//System.out.println(logical+ " logical");
	ProcessLiterals(t);
	predicates = new ArrayList<Predicate>();
	int cnt = 0;
	for(String s: LHS){
		Predicate predicate = new Predicate();
		int indexOfDot = s.indexOf(".");
		String lhsname = s.substring(indexOfDot+1);
		Column c = null;
		if(isLiteral.get(cnt))
		{
			switch(operator.get(cnt)) 
			{
				case "=":
				predicate.setType('E');
				break;
				case "IN":
				predicate.setType('I');
				break;
				default:
				predicate.setType('R');
				break;
			}
			predicate.setText(s.concat(operator.get(cnt)).concat(RHS.get(cnt)));
			predicate.setFf1(11111);
			
		}
		else
		{
		for(Column col: t.getColumns()) {
			//System.out.println("COL LOOP " + col.getColName());
			if (col.getColName().equalsIgnoreCase(lhsname)) {
				c = col;
				break;
			}
		}
		//System.out.println(" cols ck pt  " + lhsname);
		//System.out.println("COLS CK PT " + c );
		switch(operator.get(cnt)) {
		case "=": 
			predicate.setCard1(c.getColCard());
			predicate.setFf1(1/new Double(c.getColCard()));
			predicate.setType('E');
			predicate.setText(s.concat(" = ").concat(RHS.get(cnt)));
			break;
		case "IN": 
			predicate.setCard1(c.getColCard());
			predicate.setType('I');
			String pred [] = RHS.get(cnt).split(",");
			int noofcols = pred.length;
			if(textdescriptionflag) {
				predicate.setFf1(noofcols/new Double(c.getColCard()));
				predicate.setDescription(s.concat(" IN ").concat(RHS.get(cnt)));
				StringBuffer sb = new StringBuffer();
				String array []  = RHS.get(0).split(" ");
				for(String arr: array) {
					//System.out.println(arr + " in loop");
					if (arr.trim().length() != 0 && arr.trim().equals("(") == false && arr.trim().equals(",") == false && arr.trim().equals(")") == false) {
						////System.out.println(arr + " in if");
						sb.append(LHS.get(0)).append(" = "+arr + " OR ");
					}
				}
				//System.out.println(sb.toString().substring(0, sb.toString().length() - 3) + " sysoVIK");
				predicate.setText(sb.toString().substring(0, sb.toString().length() - 3));
			} else {
				if(noofcols > 1) {
					predicate.setFf1(noofcols/new Double(c.getColCard()));
				} else {
					predicate.setType('E');
					predicate.setFf1(1.0/new Double(c.getColCard()));
					predicate.setText(s.concat(" IN ").concat(RHS.get(cnt)));
					int indexofopen = pred[0].indexOf('(');
					int indexofclose = pred[0].indexOf(')');
					predicate.setDescription(s.concat(" = ").concat(pred[0].substring(indexofopen + 1, indexofclose).trim()));
				}
				predicate.setText(s.concat(" IN ").concat(RHS.get(cnt)));
			}
			
			break;
		default: 
			predicate.setCard1(c.getColCard());
			predicate.setType('R');
			predicate.setText(s.concat(" ").concat(operator.get(cnt) + " ").concat(RHS.get(cnt)));
			Column.ColType colType = c.getColType();
			String hikey = c.getHiKey().toUpperCase();
			String lokey = c.getLoKey().toUpperCase();
			if(operator.get(cnt).charAt(0)=='<') {
				if(colType.toString().equals("CHAR")) {
					hikey = hikey.substring(0, 2);
					lokey = lokey.substring(0, 2);
					double hikeyI = ((hikey.charAt(0)-64)* 26 + (hikey.charAt(1)-64)*1);
					double lokeyI = ((lokey.charAt(0)-64)* 26 + (lokey.charAt(1)-64)*1);
					double literal = ((RHS.get(cnt).charAt(0)-64)* 26 + (RHS.get(cnt).charAt(1)-64)*1);
					double ff = (literal - lokeyI) / new Double(hikeyI - lokeyI);
					predicate.setFf1(ff);
				} else {
					//System.out.println(colType);
					//System.out.println("IN INT");
					double hikeyI = Integer.parseInt(hikey);
					double lokeyI = Integer.parseInt(lokey);
					double literal = Integer.parseInt(RHS.get(cnt));
					double ff = (literal - lokeyI) / new Double(hikeyI - lokeyI);
					predicate.setFf1(ff);
				}
			} else {
				if(colType.toString().equals("CHAR")) {
					hikey = hikey.substring(0, 2);
					lokey = lokey.substring(0, 2);
					int hikeyI = ((hikey.charAt(0)-64)* 26 + (hikey.charAt(1)-64)*1);
					int lokeyI = ((lokey.charAt(0)-64)* 26 + (lokey.charAt(1)-64)*1);
					int literal = ((RHS.get(cnt).charAt(0)-64)* 26 + (RHS.get(cnt).charAt(1)-64)*1);
					double ff = (hikeyI - literal) / new Double (hikeyI - lokeyI);
					predicate.setFf1(ff);
				} else {
					int hikeyI = Integer.parseInt(hikey);
					int lokeyI = Integer.parseInt(lokey);
					//System.out.println(hikeyI);
					//System.out.println(lokeyI);
					int literal = Integer.parseInt(RHS.get(cnt));
					//System.out.println("CALCULATING FF**********");
					double ff = (hikeyI - literal) / new Double(hikeyI - lokeyI);
					//System.out.println(ff);
					predicate.setFf1(ff);
				}
			}
			break;
		}
		}
		predicates.add(predicate);
		cnt++;
	}
	Map<Double, String> result = new HashMap<Double, String> ();
	for(Predicate p1 : predicates) {
		result.put(p1.getFf1(), p1.getText());
	}
	Map<Double,String> r = new TreeMap<Double,String> (result);
	
	ArrayList<Integer> seqval= new ArrayList<Integer>();
	ArrayList<String> labl = new ArrayList<String> ();
	int count = 1,indx = 0;
	
	for (Map.Entry<Double, String> entry : r.entrySet())
	{
	    //System.out.println(entry.getKey() + "/" + entry.getValue());
	    seqval.add(count++);
	    labl.add(entry.getValue());
	}
	//System.out.println(seqval);
	//System.out.println(labl);
	int index1 = 0;
	for (String s : labl)
	for(Predicate pa : predicates) {
		if(s.equals(pa.getText())) {
			pa.setSequence(seqval.get(index1++));
			break;
		}
	}
	if(mLiteral)
		modifySequence();
	removeLiterals();
	
	ProcessConflictingPredicates(t);
	ArrayList<Integer> lhsid = new ArrayList<Integer>();
	for(String s: LHS) { 
		int index11 = s.indexOf(".");
		for(Column c: t.getColumns()) {
			if(c.getColName().equalsIgnoreCase(s.substring(index11+1))) {
				lhsid.add(c.getColId());
				break;
			}
	}
	}//System.out.println("lhsid " + lhsid);
	String tempidxname = "";
	int x = 0;
	ArrayList<String> lhsidxname = new ArrayList<String> ();
	ArrayList<Integer> lhsidxcol = new ArrayList<Integer>();
	for(int a : lhsid) {
		boolean noindexfound = true;
		tempidxname = "";
		x = t.getNumColumns() + 1;
	for(Index id: t.getIndexes()) {
		for(Index.IndexKeyDef ikd : id.getIdxKey()) {
			if(a == ikd.colId) {
					if(ikd.idxColPos < x) {
						x = ikd.idxColPos;
						tempidxname = id.getIdxName();
						noindexfound = false;
						break;
					}
				}
			}
		}
	if(!noindexfound) {
		lhsidxname.add(tempidxname); 
		lhsidxcol.add(x);
	}
	else {lhsidxname.add("NOINDEX");
	lhsidxcol.add(-1);
	 }
	}
	//System.out.println(lhsidxname);
	//System.out.println(lhsidxcol);
	//System.out.println(LHS);
	//System.out.println(lhsid);
	new Predicate().printTable(new DbmsPrinter(), predicates);
	//System.out.println("*******CHECK POINT*************");
	//System.out.println(LHS + " LHS");
	//System.out.println(operator+ " operator");
	//System.out.println(RHS + " RHS");
	//System.out.println(logical+ " logical");
	ArrayList<String> columnList = new ArrayList<String> ();
	for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
		if(!sqlarray.get(i).equals(",")) {
			columnList.add(sqlarray.get(i).split("\\.")[1]);
		}
	}
	//System.out.println(columnList + " colslist");
	//column list extraction end
	if(logical.contains("OR")) {
		p.accessType = 'R';
		p.prefetch = 'S';
		//work on predicates --done
			
	} else if(sqlarray.contains("AND") || andorindex.size() == 0) { //contains only AND
		ArrayList<String> lhswodot = new ArrayList<String> ();
			for(String s: LHS) {
				lhswodot.add(s.substring(s.indexOf('.') + 1));
			}
			//System.out.println(lhswodot + " lhswo.");
			//System.out.println(columnList);
			ArrayList<Integer> columnListIndex = new ArrayList<Integer> ();
			for(String s: lhswodot) {
				for(Column c: t.getColumns()) {
					if(c.getColName().trim().equalsIgnoreCase(s.trim())) {
						columnListIndex.add(c.getColId());
						break; //handle LITERAL
					}
				}
			}
			//System.out.println(columnListIndex + " columnListIndex");
			ArrayList<String> ind = new ArrayList<String> ();
			ArrayList<ArrayList <Integer>> indval = new ArrayList<ArrayList<Integer>> (); 
			//extract available columns n index
			Set<Integer> colsavinindex = new HashSet<Integer> ();
			for(Index i: t.getIndexes()) {
				ind.add(i.getIdxName());
				ArrayList<Integer> rem = new ArrayList<Integer> ();
				for(Index.IndexKeyDef ikd: i.getIdxKey()) {
					rem.add(ikd.colId);
					colsavinindex.add(ikd.colId);
				}
				indval.add(rem);
			}
			ArrayList<Integer> columnListIndexrep = new ArrayList<Integer>();
			for(int coas: columnListIndex) {
				if(colsavinindex.contains(coas)) {
					columnListIndexrep.add(coas);
				}
			}
			//System.out.println(ind + "ind <-- index name");
			//System.out.println(indval + " INDVALLL");
			ArrayList<ArrayList<String>> mat = new ArrayList<ArrayList<String>> ();
			//System.out.println(colsavinindex + " colsin index set");
			boolean containsR = operator.contains(">") || operator.contains(">=") || operator.contains("<") || operator.contains("<=");
			//System.out.println(columnListIndex+ " F###");
			if(!containsR) {
			for(ArrayList<Integer> ai: indval) { //array of array 
				ArrayList<String> temp = new ArrayList<String> ();
				for(int i = 0; i < ai.size(); i++) {
					if (columnListIndexrep.contains(ai.get(i))) {
						if(i == 0) {
							temp.add("M");
						} else {
							if(temp.get(i - 1).equals("M")) {
								temp.add("M");
							} else temp.add("S");
						}
					} else {
						temp.add("N");
					}
				}
				mat.add(temp);
			} } else { //handle range
				for(ArrayList<Integer> ai: indval) { //array of array 
					ArrayList<String> temp = new ArrayList<String> ();
					//System.out.println(ai + " ai");
					int j = -1;
					
					for(int i = 0; i < ai.size(); i++) {
						j++;
						//System.out.println("IN RANGE CHK outside else");
						//System.out.println(operator);
						//System.out.println(columnListIndex);
						//System.out.println(columnListIndexrep);
						//System.out.println(lhsid);
						if (columnListIndexrep.contains(ai.get(i))) {
							////System.out.println("INDEX CK");
							////System.out.println(columnListIndexrep.indexOf(ai.get(j)) + " gg "+ ai.get(i));
							if(i == 0) {
								temp.add("M");
							} else {
								//System.out.println("IN RANGE CHK");
								if(operator.get(i - 1).trim().charAt(0) == '<' 
										|| 
									operator.get(i - 1).trim().charAt(0) == '>') {
									if(temp.get(j-1).equals("M"))
									temp.add("M");
								} else {
									temp.add("S");
								}
							}
						} else {
							temp.add("N");
						}
					}
					mat.add(temp);
				}
			}
			//System.out.println(mat + " mat");
			ArrayList<Integer> msn = new ArrayList<Integer>();
			int m = 0, s = 0;
			
			for(ArrayList<String> ai: mat) {
				m = 0;
				s = 0;
				for(String snm: ai) {
					if(snm.equals("M")) {
						m++; 
					} else if(snm.equals("S")) {
						s++;
					}
				}
				msn.add(Integer.parseInt(new String(""+m+s)));
			}
			//System.out.println(msn + " msn");
			int X = 0;
			int target = 0;
			String accName = "";
			for(int tar: msn) {
				//System.out.println(target + " targ" + tar + " tar");
				if(target < tar) {
					//System.out.println("n if");
					target = tar;
					accName = ind.get(X);
					////System.out.println(X + " X");
				}
				X++;
			}
			/*
			 * tie breaker code
			 */
			ArrayList<ArrayList<String>> matMatch = new ArrayList<ArrayList<String>> ();
			ArrayList<Integer> tiebreaker = new ArrayList<Integer> ();
			ArrayList<String> indMatch = new ArrayList<String> ();
			ArrayList<ArrayList<Integer>> indvalMatch = new ArrayList<ArrayList<Integer>> ();
			X = 0;
			for(int tie: msn) {
				if(target == tie) {
					tiebreaker.add(target);
					if(mat.get(X).contains("M") || mat.get(X).contains("S")) {
						matMatch.add(mat.get(X));
						indMatch.add(ind.get(X));
						indvalMatch.add(indval.get(X));
					}
					
				}
				X++;
			}
			//if(tiebreaker.size() > 1) {
			//System.out.println(ind + " ind tiebreaker code");
			//System.out.println(mat + " mat");
			//System.out.println(indval + " indval");
			//System.out.println(tiebreaker + " tiebreaker");
			//System.out.println(matMatch + " matMatch");
			//System.out.println(indMatch + " indMatch");
			//System.out.println(indvalMatch  + " indvalMatch");
			
			boolean tiebreaker1 = false;
			X = 0;
			ArrayList<Integer> fftie =  new ArrayList<Integer> ();
			ArrayList<String> fftieindex = new ArrayList<String>();
			if(matMatch.size() > 1) {
				X = 0;
				int countOfMS = 0;
				boolean mflag = false;
				
				for(String st: matMatch.get(0)) {
					if(st.equals("M") || st.equals("S")) {
						countOfMS++;
						if(st.equals("M")) {
							mflag = true;
						}
					}
				}
				ArrayList<Double> ffarr = new ArrayList<Double> ();
				ArrayList<String> ffarrcolind = new ArrayList<String>();
				
				if(countOfMS == 1) {
					X = 0;
					int indofms = 0;
					for(ArrayList<String> as : matMatch) {
						if(mflag) {
							indofms = as.indexOf("M");
						}else {
							indofms = as.indexOf("S");
						}
							int colid = indvalMatch.get(X).get(indofms);
							ffarrcolind.add(indMatch.get(X));
							String colname = "";
							for(Column c: t.getColumns()) {
								if(c.getColId() == colid) {
									colname = c.getColName();
									break;
								}
							}
							for(Predicate per : predicates) {
								if(per.text.toLowerCase().contains(colname.toLowerCase())) {
									ffarr.add(per.ff1);
									//System.out.println("In for " + per.text);
								}
							}
						X++;
					}
					//System.out.println(ffarr + " ffarr count = 1");
					//System.out.println(ffarrcolind);
					//System.out.println();
				} else {
					X = 0;
					for(ArrayList<String> as : matMatch) {
						int inds = 0;
						ArrayList<Integer> coli = new ArrayList<Integer>();
						ArrayList<String> coln = new ArrayList<String> ();
						ArrayList<Double> ffa = new ArrayList<Double> ();
						for(String st: as ) {
							if(st.equals("M") || st.equals("S")) {
								coli.add(indvalMatch.get(X).get(inds));
							}
							inds++;
						}
						for(int colid: coli)
						for(Column c: t.getColumns()) {
							if(c.getColId() == colid) {
								coln.add(c.getColName()); break;
							}
						}
						double pred = 1.0;
						for(String colname: coln)
						for(Predicate per : predicates) {
							if(per.text.toLowerCase().contains(colname.toLowerCase())) {
								ffa.add(per.ff1);
								//System.out.println("In for " + per.text);
							}
						}
						for(Double d: ffa) {
							pred *= d;
						}
						ffarr.add(pred);
						ffarrcolind.add(indMatch.get(X));
						X++;
					}
				}
				double min = ffarr.get(0);
				X = 0;
				
				for(Double doub : ffarr) {
					if(doub < min) {
						min = doub;
						accName = ffarrcolind.get(X);
					}
					X++;
				}
				tiebreaker1 = true;
				p.accessName = accName;
			}
			
			//System.out.println("FFFFFFFFFFFFFF");
			//System.out.println(fftie);
			//System.out.println(fftieindex);
			ArrayList<String> ffcolname = new ArrayList<String> ();
			ArrayList<Double> ff = new ArrayList<Double> ();
			for(int i : fftie) {
				for(Column cc: t.getColumns()) {
					if(cc.getColId() == i) {
						ffcolname.add(cc.getColName());
						break;
					}
				}
			}
			//System.out.println(ffcolname + " ffcolname");
			for(String ffc : ffcolname)
			for(Predicate pr : predicates) {
				if(pr.text.toLowerCase().contains(ffc.toLowerCase())) {
					//System.out.println(ffc + " "  + pr.ff1);
					ff.add(pr.ff1);
					break;
				}
			}
			X = 0;
			double ffti = 10.0;
			String accN = "5";
			for(int i = 0; i < ff.size(); i++) {
				//System.out.println(ff.get(i));
				if(ff.get(i) < ffti) {
					//System.out.println("Inside if");
					ffti = ff.get(i);
					accN = fftieindex.get(i);
				}
			}
			//System.out.println(accN);
			//System.out.println("accName test " + accName);
			//}
			/*
			 * tie breaker code end 
			 */
			/*if(tiebreaker.size() > 1) {
				if(fftie.size() > 1) p.accessName = accN;
				else p.accessName = indexNmae;
				//System.out.println(p.accessName + " end oftie");
				
			}*/
			//System.out.println("CHK PT target " + target);
			p.accessName = accName;
			if(target != 0) {
				if(!tiebreaker1)
				p.accessName = accName;
				String sat = ""+target;
				if(sat.length() < 2) {
					p.matchCols = 0;
				}
				else {
					
					p.matchCols = Integer.parseInt(new Character(sat.charAt(0)).toString());
				}
				
				p.prefetch = ' ';
				p.sortC_orderBy = 'N';
				p.table1Card = t.getTableCard();
				boolean flag = false;
				if(operator.contains("IN")) {
					int nd = operator.indexOf("IN");
					//columnListIndex
					int col = columnListIndex.get(nd);
					for(Index I : t.getIndexes()) {
						if(I.getIdxName().trim().equalsIgnoreCase(accName.trim())) {
							for(Index.IndexKeyDef ikd: I.getIdxKey()) {
								if(ikd.colId == col) {
									////System.out.println(RHS.get(nd).split(",").length + " RHS");
									if(RHS.get(nd).split(",").length > 1) {
										flag = true;
										break;
									}
								}
							}
						}
					}
					
				}
				if(flag) {
					p.accessType = 'N';
				} else {
					p.accessType = 'I';
				}
				
			}
			//System.out.println(columnList + " columnList");
			ArrayList<Integer> colListInt = new ArrayList<Integer> ();
			for(String co: columnList) {
				for(Column c: t.getColumns()) {
					if(c.getColName().trim().equalsIgnoreCase(co.trim())) {
						colListInt.add(c.getColId());
						break;
					}
				}
			}
			//System.out.println(colListInt + " colListInt");
			//System.out.println(colsavinindex + " colsavinindex");
			boolean indexonlyflag = true;
			for(int inte: colListInt) {
				//System.out.println("FAFAFASTA!!");
				if(!indvalMatch.contains(inte)) {
					//System.out.println("AFTER GGA");
					indexonlyflag = false;
					break;
				}
			}
			boolean indexonlyFP = true;
			for(int inte: columnListIndex) {
				if(!indvalMatch.contains(inte)) {
					indexonlyFP = false;
					break;
				} 
			}
			if(indexonlyflag && indexonlyFP && p.accessType != 'R')
			p.indexOnly = 'Y';
			if(p.accessType == 'R') p.prefetch = 'S';
			ArrayList<Boolean> colex = new ArrayList<Boolean>();
			ArrayList<Integer> selectlist = new ArrayList<Integer> ();
			for(String col: columnList) {
				for(Column c: t.getColumns()) {
					if(col.trim().equalsIgnoreCase(c.getColName().trim())) {
						selectlist.add(c.getColId());
						break;
					}
				}
			}
			//System.out.println(selectlist);
			Index indite = null;
			for(int ai : selectlist) {
				
				for(Index inderr : t.getIndexes()) {
					if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
						indite = inderr;
						break;
					}
				}
				//ab = 0;
				if(indite != null)
				for(Index.IndexKeyDef ikd: indite.getIdxKey()) {
					if(ikd.colId == ai) {
							//ab = 1;
							colex.add(true);
					} else {
						colex.add(false);
					}
				}
				
			}
			//p.matchCols = matchcols;
			//System.out.println(colex + "CK PT");
			////System.out.println(columnListIndex + " CK PT");
			//System.out.println(columnListIndexrep + "CK PT");
			//System.out.println("CKK PT " + p.accessName);
			for(int ai : columnListIndexrep) {
				Index indiite = null;
				for(Index inderr : t.getIndexes()) {
					if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
						indiite = inderr;
						break;
					}
				}
				//ab = 0;
				if(indiite != null)
				for(Index.IndexKeyDef ikd: indiite.getIdxKey()) {
					if(ikd.colId == ai) {
							//ab = 1;
							colex.add(true);
							//matchcols++;
					} else {
						colex.add(false);
					}
				}
				//System.out.println(ai + " AI BEFORE EXIT");
			}
			//System.out.println("SELECT LIST " + selectlist);
			//System.out.println("Predicate list" + columnListIndex);
			ArrayList<Integer> indexOnlydecider = new ArrayList<Integer> ();
			for(int i : columnListIndex) {
				indexOnlydecider.add(i);	
			}
			for(int i : selectlist) {
				if(!indexOnlydecider.contains(i))
					indexOnlydecider.add(i);
			}
			
			ArrayList<Integer> indexd = null;
			if(p.accessType != 'R')
			indexd = indvalMatch.get(indMatch.indexOf(p.accessName));
			//System.out.println(indexd + " indexd");
			boolean indexOnlyflag = true;
			for(int i : indexOnlydecider) {
				if(indexd != null && !indexd.contains(i)) {
					indexOnlyflag = false;
					break;
				}
			}
			if(indexOnlyflag && p.accessType != 'R') {
				p.indexOnly = 'Y';
			} else {
				p.indexOnly = 'N';
			}
			if(p.accessType == 'I' || p.accessType == 'N' ) {
				if(p.accessName != null)
					if (p.accessName.trim().length() > 0)
				p.prefetch = ' ';
			}else {
				p.prefetch = 'S';
			}
		} else {
			//single predicate 
			//System.out.println("HANDLE SINGLE PREDICATE");
			//System.out.println(LHS);
			//System.out.println(RHS);
			//System.out.println(operator);
			for(Column c: t.getColumns()) {
				////System.out.println(LHS.get(0).split("\\.")[0]);
				if(c.getColName().trim().equalsIgnoreCase(LHS.get(0).split("\\.")[1])) {
					//System.out.println(c.getColId());
					break;
				}
			}
		}
	if(p.accessType != 'R')
	p.setAccessName(t.getTableName()+p.getAccessName());
	
	p.printTable(new DbmsPrinter());
		
	}

public void nowhereOrderby(ArrayList<String> sqlarray, Table t) {
	//System.out.println("In nowhere orderby method");
	ArrayList<String> ordercols = new ArrayList<String>();
	ArrayList<Character> order = new ArrayList<Character> ();
	StringBuffer sb = new StringBuffer();
	for(int i =  sqlarray.indexOf("ORDER") + 2; i < sqlarray.size(); i++) {
		sb.append(sqlarray.get(i));
		sb.append(" ");
	}
	//for(String s: strArr)
	//System.out.print(sb);
	String strArr [] = sb.toString().split(",");
	//System.out.println("Final");
	sb = new StringBuffer();
	//ArrayList<String> resultant = new ArrayList<String> ();
	//int counter = strArr.length;
	for(String s: strArr) {
		//System.out.println(s);
		////System.out.print(s + "\n ");
		String [] stemp = new String[2];
		if(s.trim().contains("D")) {
			s = s.trim();
			stemp = s.split(" " );
			ordercols.add(stemp[0].split("\\.")[1].trim());
			order.add('D');
		} else {
			if(s.trim().contains("A") || s.trim().contains("ASC")) {
				s = s.trim();
				
				////System.out.println("DEBUG " + s);
				stemp = s.split(" " );
				////System.out.println(stemp[0]);
				ordercols.add(stemp[0].split("\\.")[1].trim());
			} else {
				ordercols.add(s.split("\\.")[1].trim());
			}
			order.add('A');	
		}
		
	}
	
	
	//System.out.println(order);
	//System.out.println(ordercols + " order lst");
	////System.out.println(t.getTableCard() + " bii ");
		////System.out.println(ordercols);
	
		ArrayList<Integer> ordercolid = new ArrayList<Integer> ();
		for(String s : ordercols) {
			for(Column c : t.getColumns()) {
				if(s.trim().equalsIgnoreCase(c.getColName().trim())) {
					ordercolid.add(c.getColId());
					break;
				}
			}
		}
		ArrayList<String> finalOrder = new ArrayList<String> ();
		for(int i = 0; i < ordercolid.size(); i++) {
			finalOrder.add(ordercolid.get(i)+new String(order.get(i).toString()));
		}
		ArrayList<String> finalC = new ArrayList<String> ();
		for(Index i: t.getIndexes()) {
			boolean breakflag = false;
			finalC = new ArrayList<String> ();
			for(Index.IndexKeyDef ikd: i.getIdxKey()) {
				String des = "A";
				if(ikd.descOrder) {
					des = "D";
				}
				finalC.add(ikd.colId+des);
				
			}
			for(int ind = 0; ind < finalOrder.size(); ind++) {
				if(finalC.get(ind).equals(finalOrder.get(ind))) {
					breakflag = true;
					//System.out.println(finalC.get(ind) + " finalC.get(ind)");
					//handle cardinality
					break;
				} //else if () {
					
				//}
				
			}
				if(breakflag)
				{
				break ; }
				//System.out.println(i.getIdxName());
				////System.out.println("assigning i");
			
		}
		//System.out.println(ordercols + " ordercols");
		//System.out.println(ordercolid + " ordercolid");
		//System.out.println(finalOrder + " finalOrder");
		ArrayList<String> finalOrderReverse = new ArrayList<String> ();
		for(String s: finalOrder) {
			//System.out.println(s);
			String char2 = s.substring(s.length() - 1);
			String char2R = "A";
			if (char2.equals("A")) {
				char2R = "D";
			}
			String char1 = s.substring(0, s.length() - 1);
			finalOrderReverse.add(char1+char2R);
		}
		//System.out.println(finalOrderReverse + " finalOrderReverse");
		int arraySize = finalOrder.size();
		ArrayList<ArrayList<String>> in = new ArrayList<ArrayList<String>>();
		for(Index i : t.getIndexes()) {
			ArrayList<String> id = new ArrayList<String> ();
			////System.out.println(i.getIdxName());
			int ite = 0;
			for(Index.IndexKeyDef ikd: i.getIdxKey()) {
				////System.out.println(ikd.colId  +" "+ikd.descOrder);
				String des = "A";
				if(ikd.descOrder) {
					des = "D";
				}
				id.add(ikd.colId+des);
				ite++;
				if(ite >= arraySize) {
					break;
				}
			}
			in.add(id);
		}
		//System.out.println(in + " in");
		////System.out.println(finalC + " finalC") ;
		int indext = 0;
		int indexofindex = 99;
		//int noofcols
		int inde = 0;
		String pdotaccessname = "";
		for(ArrayList<String> a: in) {
			int noofcols = t.getIndexes().get(indext).getIdxKey().size();
			//System.out.println(noofcols + " noofcols");
			//System.out.println(indexofindex + " ioi");
			if(a.equals(finalOrder)) {
				if(indexofindex > noofcols) { indexofindex = noofcols; inde = indext;}
				//System.out.println("match with final order" + t.getIndexes().get(indext).getIdxName());
				pdotaccessname = t.getIndexes().get(indext).getIdxName();
				break;
			} else if (a.equals(finalOrderReverse)) {
				if(indexofindex > noofcols) {indexofindex = noofcols; inde = indext;}
				//System.out.println("match wth reverse" + t.getIndexes().get(indext).getIdxName());
				pdotaccessname = t.getIndexes().get(indext).getIdxName();
				
			}
			indext++;
		}
		//System.out.println(inde + " inde of ind");
		ArrayList<String> columnList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i).
						split("\\.")[1]);
			}
		}
		//System.out.println(columnList + " colslist");
		
		PlanTable p = new PlanTable();
		p.queryBlockNo = 1;
		//System.out.println("--------afer qblk assignment ---");
		if(indexofindex == 99) {
			//System.out.println(" **** INSDE IF");
			p.accessType = 'R';
			p.prefetch = 'S';
			p.sortC_orderBy = 'Y';
			p.table1Card = t.getTableCard();
		} else {
			p.accessType = 'I';
			p.accessName = pdotaccessname;
			ArrayList<Boolean> colex = new ArrayList<Boolean>();
			ArrayList<Integer> selectlist = new ArrayList<Integer> ();
			for(String col: columnList) {
				for(Column c: t.getColumns()) {
					if(col.trim().equalsIgnoreCase(c.getColName().trim())) {
						selectlist.add(c.getColId());
						break;
					}
				}
			}
			//System.out.println(selectlist);
			//System.out.println(colex);
			int matchcols = 0;
			for(int a : selectlist) {
				Index indite = null;
				for(Index inderr : t.getIndexes()) {
					if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
						indite = inderr;
						break;
					}
				}
				for(Index.IndexKeyDef ikd: indite.getIdxKey()) {
					if(ikd.colId == a) {
							colex.add(true);
							matchcols++;
					} 
				}
			} 
			//System.out.println(matchcols + " check pt");
			//System.out.println(colex);
			if(!sqlarray.contains("WHERE"))
			p.matchCols = 0;
			if(!colex.contains(false)) {
				p.indexOnly = 'Y';
			} else {
				p.indexOnly = 'N';
			}
			if(p.accessType == 'I' ) {
				if(p.accessName != null)
					if (p.accessName.trim().length() > 0)
				p.prefetch = ' ';
			}else {
				p.prefetch = 'S';
			}
			p.sortC_orderBy = 'N';
			p.table1Card = t.getTableCard();
		}
		if(p.accessType != 'R')
		p.setAccessName(t.getTableName()+p.getAccessName());
		
		p.printTable(new DbmsPrinter());
		if(!wo)
		new Predicate().printTable(new DbmsPrinter(), new ArrayList<Predicate>());
	
	}
private void whereOrderByWithIndex(ArrayList<String> sqlarray, Table t , String passedIndex , PlanTable planT) {
	//System.out.println("In nowhere orderby method");
	ArrayList<String> ordercols = new ArrayList<String>();
	ArrayList<Character> order = new ArrayList<Character> ();
	StringBuffer sb = new StringBuffer();
	for(int i =  sqlarray.indexOf("ORDER") + 2; i < sqlarray.size(); i++) {
		sb.append(sqlarray.get(i));
		sb.append(" ");
	}
	//for(String s: strArr)
	//System.out.print(sb);
	String strArr [] = sb.toString().split(",");
	//System.out.println("Final");
	sb = new StringBuffer();
	//ArrayList<String> resultant = new ArrayList<String> ();
	//int counter = strArr.length;
	for(String s: strArr) {
		//System.out.println(s);
		////System.out.print(s + "\n ");
		String [] stemp = new String[2];
		if(s.trim().contains("D")) {
			s = s.trim();
			stemp = s.split(" " );
			ordercols.add(stemp[0].split("\\.")[1].trim());
			order.add('D');
		} else {
			if(s.trim().contains("A") || s.trim().contains("ASC")) {
				s = s.trim();
				
				////System.out.println("DEBUG " + s);
				stemp = s.split(" " );
				////System.out.println(stemp[0]);
				ordercols.add(stemp[0].split("\\.")[1].trim());
			} else {
				ordercols.add(s.split("\\.")[1].trim());
			}
			order.add('A');	
		}
		
	}
	
	
	//System.out.println(order);
	//System.out.println(ordercols + " order lst");
	////System.out.println(t.getTableCard() + " bii ");
		////System.out.println(ordercols);
	
		ArrayList<Integer> ordercolid = new ArrayList<Integer> ();
		for(String s : ordercols) {
			for(Column c : t.getColumns()) {
				if(s.trim().equalsIgnoreCase(c.getColName().trim())) {
					ordercolid.add(c.getColId());
					break;
				}
			}
		}
		ArrayList<String> finalOrder = new ArrayList<String> ();
		for(int i = 0; i < ordercolid.size(); i++) {
			finalOrder.add(ordercolid.get(i)+new String(order.get(i).toString()));
		}
		ArrayList<String> finalC = new ArrayList<String> ();
		for(Index i: t.getIndexes()) {
			if(i.getIdxName().trim().equalsIgnoreCase(passedIndex)) {
			
			boolean breakflag = false;
			finalC = new ArrayList<String> ();
			for(Index.IndexKeyDef ikd: i.getIdxKey()) {
				
				String des = "A";
				if(ikd.descOrder) {
					des = "D";
				}
				finalC.add(ikd.colId+des);
				
			}
			for(int ind = 0; ind < finalOrder.size(); ind++) {
				if(finalC.get(ind).equals(finalOrder.get(ind))) {
					breakflag = true;
					//System.out.println(finalC.get(ind) + " finalC.get(ind)");
					//handle cardinality
					break;
				} //else if () {
					
				//}
				
			}
				if(breakflag)
				{
				break ; }
				//System.out.println(i.getIdxName());
				////System.out.println("assigning i");
		}
		}
		//System.out.println(ordercols + " ordercols");
		//System.out.println(ordercolid + " ordercolid");
		//System.out.println(finalOrder + " finalOrder");
		ArrayList<String> finalOrderReverse = new ArrayList<String> ();
		for(String s: finalOrder) {
			//System.out.println(s);
			String char2 = s.substring(s.length() - 1);
			String char2R = "A";
			if (char2.equals("A")) {
				char2R = "D";
			}
			String char1 = s.substring(0, s.length() - 1);
			finalOrderReverse.add(char1+char2R);
		}
		//System.out.println(finalOrderReverse + " finalOrderReverse");
		int arraySize = finalOrder.size();
		ArrayList<ArrayList<String>> in = new ArrayList<ArrayList<String>>();
		for(Index i : t.getIndexes()) {
			if(i.getIdxName().trim().equalsIgnoreCase(passedIndex)) {
			ArrayList<String> id = new ArrayList<String> ();
			////System.out.println(i.getIdxName());
			int ite = 0;
			for(Index.IndexKeyDef ikd: i.getIdxKey()) {
				////System.out.println(ikd.colId  +" "+ikd.descOrder);
				String des = "A";
				if(ikd.descOrder) {
					des = "D";
				}
				id.add(ikd.colId+des);
				ite++;
				if(ite >= arraySize) {
					break;
				}
			}
			in.add(id);
			}
		}
		//System.out.println(in + " in");
		////System.out.println(finalC + " finalC") ;
		int indext = 0;
		int indexofindex = 99;
		//int noofcols
		int inde = 0;
		String pdotaccessname = "";
		//System.out.println("WO CK " + in);
		//System.out.println(finalOrder);
		//System.out.println(finalOrderReverse);
		for(ArrayList<String> a: in) {
			int noofcols = t.getIndexes().get(indext).getIdxKey().size();
			//System.out.println(noofcols + " noofcols");
			//System.out.println(indexofindex + " ioi");
			if(a.equals(finalOrder)) {
				if(indexofindex > noofcols) { indexofindex = noofcols; inde = indext;}
				//System.out.println("match with final order" + t.getIndexes().get(indext).getIdxName());
				pdotaccessname = t.getIndexes().get(indext).getIdxName();
				break;
			} else if (a.equals(finalOrderReverse)) {
				if(indexofindex > noofcols) {indexofindex = noofcols; inde = indext;}
				//System.out.println("match wth reverse" + t.getIndexes().get(indext).getIdxName());
				pdotaccessname = t.getIndexes().get(indext).getIdxName();
				
			}
			indext++;
		}
		//System.out.println(inde + " inde of ind");
		ArrayList<String> columnList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i).
						split("\\.")[1]);
			}
		}
		//System.out.println(columnList + " colslist");
		
		PlanTable p = new PlanTable();
		p.queryBlockNo = 1;
		//System.out.println("--------afer qblk assignment ---");
		//System.out.println(indexofindex);
		if(indexofindex == 99) {
			//System.out.println(" **** INSDE IF");
			p.accessType = 'R';
			p.prefetch = 'S';
			planT.sortC_orderBy = 'Y';
			p.table1Card = t.getTableCard();
		} else {
			p.accessType = 'I';
			p.accessName = pdotaccessname;
			ArrayList<Boolean> colex = new ArrayList<Boolean>();
			ArrayList<Integer> selectlist = new ArrayList<Integer> ();
			for(String col: columnList) {
				for(Column c: t.getColumns()) {
					if(col.trim().equalsIgnoreCase(c.getColName().trim())) {
						selectlist.add(c.getColId());
						break;
					}
				}
			}
			//System.out.println(selectlist);
			//System.out.println(colex);
			int matchcols = 0;
			for(int a : selectlist) {
				Index indite = null;
				for(Index inderr : t.getIndexes()) {
					if(inderr.getIdxName().trim().equalsIgnoreCase(p.accessName)) {
						indite = inderr;
						break;
					}
				}
				for(Index.IndexKeyDef ikd: indite.getIdxKey()) {
					if(ikd.colId == a) {
							colex.add(true);
							matchcols++;
					} 
				}
			} 
			//System.out.println(matchcols + " check pt");
			//System.out.println(colex);
			if(!sqlarray.contains("WHERE"))
			p.matchCols = 0;
			if(!colex.contains(false)) {
				p.indexOnly = 'Y';
			} else {
				p.indexOnly = 'N';
			}
			if(p.accessType == 'I' ) {
				if(p.accessName != null)
					if (p.accessName.trim().length() > 0)
				p.prefetch = ' ';
			}else {
				p.prefetch = 'S';
			}
			p.sortC_orderBy = 'N';
			p.table1Card = t.getTableCard();
			//p.accessType = 'I';
			//p
			//System.out.println("PLANT getting assigned");
			planT.sortC_orderBy = 'N';
		}
		planT.printTable(new DbmsPrinter());
		if(!wo)
		new Predicate().printTable(new DbmsPrinter(), new ArrayList<Predicate>());
	

}
}