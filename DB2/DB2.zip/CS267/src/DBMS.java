import java.awt.image.IndexColorModel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 * CS 267 - Project - Implements create index, drop index, list table, and
 * exploit the index in select statements.
 */
public class DBMS {
	private static final String OUTPUT_FILE_LOC = "Output.txt";

	private static final String TABLE_FOLDER_NAME = "tables";
	private static final String TABLE_FILE_EXT = ".tab";
	private static final String INDEX_FILE_EXT = ".idx";

	private DbmsPrinter out;
	private ArrayList<Table> tables;
	private ArrayList<Index> indexes;
	private static final String COMMAND_FILE_LOC = "Commands.txt";

	public DBMS() {
		tables = new ArrayList<Table>();
		indexes = new ArrayList<Index>();
	}

	/**
	 * Main method to run the DBMS engine.
	 * 
	 * @param args
	 *            arg[0] is input file, arg[1] is output file.
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		DBMS db = new DBMS();
		db.out = new DbmsPrinter();
		Scanner in = null;
		try {
			// set input file
			if (args.length > 0) {
				in = new Scanner(new File(args[0]));
			} else {  
				in = new Scanner(new File(COMMAND_FILE_LOC));
			}

			// set output files
			if (args.length > 1) {
				db.out.addPrinter(args[1]);
			} else {
				db.out.addPrinter(OUTPUT_FILE_LOC);
			}

			// Load data to memory
			db.loadTables();

			// Go through each line in the Command.txt file
			while (in.hasNextLine()) {
				String sql = in.nextLine();
				StringTokenizer tokenizer = new StringTokenizer(sql);

				// Evaluate the SQL statement
				if (tokenizer.hasMoreTokens()) {
					String command = tokenizer.nextToken();
					if (command.equalsIgnoreCase("CREATE")) {
						if (tokenizer.hasMoreTokens()) {
							command = tokenizer.nextToken();
							if (command.equalsIgnoreCase("TABLE")) {
								db.createTable(sql, tokenizer);
							} else if (command.equalsIgnoreCase("INDEX") || command.equalsIgnoreCase("UNIQUE")) { // handle unique  
								// TODO your PART 1 code goes here
								//System.out.println("HERE");
								//System.out.println(tokenizer.nextToken());
								//db.loadTables();
								
								db.createIndex(sql);
								
							} else {
								throw new DbmsError("Invalid CREATE " + command
										+ " statement. '" + sql + "'.");
							}
						} else {
							throw new DbmsError("Invalid CREATE statement. '"
									+ sql + "'.");
						}
					} else if (command.equalsIgnoreCase("INSERT")) {
						db.insertInto(sql, tokenizer);
					} else if (command.equalsIgnoreCase("DROP")) {
						if (tokenizer.hasMoreTokens()) {
							command = tokenizer.nextToken();
							if (command.equalsIgnoreCase("TABLE")) {
								db.dropTable(sql, tokenizer);
							} else if (command.equalsIgnoreCase("INDEX")) {
								// TODO your PART 1 code goes here
								//System.out.println("IN DROP INDEX  ");
								//db.loadTables();
								
								//ArrayList<String> ss = 
										db.dropIndex(sql);
								
								
							} else {
								throw new DbmsError("Invalid DROP " + command
										+ " statement. '" + sql + "'.");
							}
						} else {
							throw new DbmsError("Invalid DROP statement. '"
									+ sql + "'.");
						}
					} else if (command.equalsIgnoreCase("RUNSTATS")) {
						// TODO your PART 1 code goes here
						db.createRunStats(sql);
						// TODO replace the table name below with the table name
						// in the command to print the RUNSTATS output
						try {
						db.printRunstats(sql.split(" ")[1]);
						} catch (Exception e) {
							System.err.println("Invalid table name..");
						}
					} else if (command.equalsIgnoreCase("SELECT")) {
						// TODO your PART 2 code goes here
						db.selectStat(sql);
						
					} else if (command.equalsIgnoreCase("--")) {
						// Ignore this command as a comment
					} else if (command.equalsIgnoreCase("COMMIT")) {
						try {
							// Check for ";"
							if (!tokenizer.nextElement().equals(";")) {
								throw new NoSuchElementException();
							}

							// Check if there are more tokens
							if (tokenizer.hasMoreTokens()) {
								throw new NoSuchElementException();
							}

							// Save tables to files
							for (Table table : db.tables) {
								db.storeTableFile(table);
							}
						} catch (NoSuchElementException ex) {
							throw new DbmsError("Invalid COMMIT statement. '"
									+ sql + "'.");
						}
					} else {
						throw new DbmsError("Invalid statement. '" + sql + "'.");
					}
				}
			}

			// Save tables to files
			for (Table table : db.tables) {
				db.storeTableFile(table);
			}
		} catch (DbmsError ex) {
			db.out.println("DBMS ERROR:  " + ex.getMessage());
			ex.printStackTrace();
		} catch (Exception ex) {
			db.out.println("JAVA ERROR:  " + ex.getMessage());
			ex.printStackTrace();
		} finally {
			// clean up
			try {
				in.close();
			} catch (Exception ex) {
			}

			try {
				db.out.cleanup();
			} catch (Exception ex) {
			}
		}
	}

	private void selectStat(String sql) {
		System.out.println("Query: " +sql);
		out.println("Query: " +sql);
		// TODO Auto-generated method stub
		ArrayList<String> sqlarray = new ArrayList<String>();
		for(String s: sql.split(" ")){
			if(s.toUpperCase().trim().length() > 0)
			sqlarray.add(s.toUpperCase().trim());
			//System.out.println(s.toUpperCase().trim());
		}
		//System.out.println(sqlarray.indexOf("WHERE") + " fage" );
		//boolean groupBy = sqlarray.contains("GROUP");
		ArrayList<String> tablenames = new ArrayList<String> ();
		ArrayList<Table> table = new ArrayList<Table> (); 
		boolean orderBy = sqlarray.contains("ORDER");
		//System.out.println(sqlarray);
		boolean where = sqlarray.contains("WHERE");
		if(orderBy && !where) {
			for(int i = sqlarray.indexOf("FROM") + 1; i < sqlarray.indexOf("ORDER"); i++) {
				if(!sqlarray.get(i).equals(",")) {
					tablenames.add(sqlarray.get(i));
				}
			}
		} else if(where) {
			//System.out.println("NSDE WHERE");
			for(int i = sqlarray.indexOf("FROM") + 1; i < sqlarray.indexOf("WHERE"); i++) {
				if(!sqlarray.get(i).equals(",")) {
					tablenames.add(sqlarray.get(i));
				}
			}
		} else {
			for(int i = sqlarray.indexOf("FROM") + 1; i < sqlarray.size(); i++) {
				if(!sqlarray.get(i).equals(",")) {
					tablenames.add(sqlarray.get(i));
				}
			}
			
		}
		for(String s: tablenames) {
			for(Table t : tables) {
				if(t.getTableName().equals(s)) {
					table.add(t);
					break;
				}
			}
		} //System.out.println(tablenames);
		if(tablenames.size() == 1) {
			System.out.println("For table " + table.get(0).getTableName());
			ArrayList<Index> indexList = table.get(0).getIndexes();
			IndexList iL = new IndexList();
			iL.list = indexList;
			iL.printTable(out);
			new SelectWithOneTable().select(sqlarray, table.get(0));
			return;
		} else if(tablenames.size() == 2) {
			System.out.println("For table " + table.get(0).getTableName());
			
			IndexList iL = new IndexList();
			iL.list = table.get(0).getIndexes();
			iL.printTable(new DbmsPrinter());
			System.out.println("For table " + table.get(1).getTableName());
			
			iL.list = table.get(1).getIndexes();
			iL.printTable(new DbmsPrinter());
			
			PlanTable planTable = new SelectWithTwoTables().select(sqlarray,table);
			planTable.printTable(out);
		}
		//boolean orderBy = sqlarray.contains("ORDER");
		ArrayList<String> ordercols = new ArrayList<String>();
		ArrayList<Character> order = new ArrayList<Character> ();
		
		if(orderBy) {
			for(int i = sqlarray.indexOf("FROM") + 1; i < sqlarray.indexOf("ORDER"); i++) {
				if(!sqlarray.get(i).equals(",")) {
					tablenames.add(sqlarray.get(i));
				}
			}
			//ArrayList<String> strArr = new ArrayList<String>();
			StringBuffer sb = new StringBuffer();
			for(int i =  sqlarray.indexOf("ORDER") + 2; i < sqlarray.size(); i++) {
				sb.append(sqlarray.get(i));
				sb.append(" ");
			}
			//for(String s: strArr)
			System.out.print(sb);
			String strArr [] = sb.toString().split(",");
			System.out.println("Final");
			sb = new StringBuffer();
			//ArrayList<String> resultant = new ArrayList<String> ();
			//int counter = strArr.length;
			for(String s: strArr) {
				System.out.println(s);
				//System.out.print(s + "\n ");
				String [] stemp = new String[2];
				if(s.trim().contains("D")) {
					//System.out.println("DESC");
					s = s.trim();
					stemp = s.split(" " );
					//resultant.add(stemp[0]+":");
					ordercols.add(stemp[0]);
					order.add('D');
				} else {
					if(s.trim().contains("ASC")) {
						s.trim();
						stemp = s.split(" " );
						System.out.println();
						//resultant.add(stemp[0]);
						//resultant.add(" :");
						ordercols.add(stemp[0]);
					} else {
						ordercols.add(s);
						//resultant.add(s);
						//resultant.add(" :");
					}
					
						
					//resultant.add("1");
					order.add('A');	
				}
				
			}
			
		
		} 
		else {
			for(int i = sqlarray.indexOf("FROM") + 1; i < sqlarray.size(); i++) {
				if(!sqlarray.get(i).equals(",")) {
					tablenames.add(sqlarray.get(i));
				}
			}
			
		}
				ArrayList<String> columnList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i));
			}
		}
	
		
		
	}

	private void createRunStats(String sql) throws Exception {
		// TODO Auto-generated method stub
		if(sql.split(" ").length > 2) {
			throw new DbmsError("Invalid statement..");
		} 
		String tabname = sql.split(" ")[1].trim();
		Table t1 = null;
		boolean tabfound = false; 
		for (Table t: tables) {
			if(t.getTableName().equals(tabname)) {
				t1 = t;
				tabfound = true;
				break;
			}
		} if (!tabfound) {
			throw new DbmsError("No such table found!! ..");
		}
		Table table = t1;
		for(int i = 0; i < t1.getData().size(); i++) {
			System.out.println(t1.getData().get(i));
			System.out.println(t1.getData().get(i).split(" +")[1]);
			//System.out.println(t1.getData());
		}
		for(Column c: t1.getColumns()) {
			ArrayList<String> col = new ArrayList<String> ();
			ArrayList<Integer> cal = new ArrayList<Integer> ();
			
			System.out.println(c.getColName());
			System.out.println(c.getColId());
			System.out.println(c.getColType());
			System.out.println(t1.getData().get(0) + " printing here ***");
			for(int i = 0; i < t1.getData().size(); i++) {
				if(c.getColType().toString().equalsIgnoreCase("CHAR")) {
					System.out.println(t1.getData().get(i).split(" +")[c.getColId()] + "after split");
					
					
					col.add(t1.getData().get(i).split(" +")[c.getColId()]/*.toLowerCase()*/);
				} else {
					System.out.println(t1.getData().get(i).split(" +")[c.getColId()] + "after split");
					
					//System.out.println(c.getColType().toString() + "Printing");
					cal.add(Integer.parseInt(t1.getData().get(i).split(" +")[c.getColId()]));
				}
			}
			if(c.getColType().toString().equals("CHAR")) {
				Collections.sort(col);
				Set<String> s = new HashSet<String>();
				for(int i = 0; i < col.size(); i++) {
					if(col.get(i).trim().isEmpty() == false)
					s.add(col.get(i));
				}
				c.setColCard(s.size());
				/*for(int i = 0; i < col.size();i++) {
					System.out.println("C hi key" + t1.getData().get(i));
					if(col.get(col.size() -1).equalsIgnoreCase(t1.getData().get(i))) {
						System.out.println("C hi key" + t1.getData().get(i));
						c.setHiKey(t1.getData().get(i));
						break;
					}
				}*/
				c.setHiKey(col.get(col.size() -1));
				/*for(int i = 0; i < col.size();i++) {
					if(col.get(0).equalsIgnoreCase(t1.getData().get(i))) {
						c.setLoKey(t1.getData().get(i));
					}
				}*/
				c.setLoKey(col.get(0));
			} else {
				Collections.sort(cal);
				Set<String> s = new HashSet<String>();
				for(int i = 0; i < cal.size(); i++) {
					if((""+cal.get(i)).trim().isEmpty() == false)
					s.add(""+cal.get(i));
				}
				c.setColCard(s.size());
				/*for(int i = 0; i < cal.size();i++) {
					if((""+cal.get(cal.size() -1)).equalsIgnoreCase(t1.getData().get(i))) {
						c.setHiKey(t1.getData().get(i));
					}
				}
				//c.setHiKey(t1.getData().get(t1.getData().indexOf(col.get(col.size() - 1).equalsIgnoreCase(anotherString))));
				for(int i = 0; i < cal.size();i++) {
					if((""+cal.get(0)).equalsIgnoreCase(t1.getData().get(i))) {
						c.setLoKey(t1.getData().get(i));
					}
				}*/
				
				
				c.setHiKey(""+cal.get(cal.size() - 1));
				c.setLoKey(""+cal.get(0));
			}
			
		} System.out.println(t1.getColumns().get(1).getColCard() + "fafeaf");
		t1.setTableCard(t1.getData().size());
		System.out.println(t1.getTableName());
		new DBMS().printRunstats(t1.getTableName());
	}

	private void dropIndex (String sql) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(tables.size());
		for(Table t :tables) {
			System.out.println("TABLE NAME " + t.getTableName());
		}
		/*for(Table t : tables) {
			if (t.getTableName().equals("T1"))
			
			System.out.println(t.getIndexes().get(0).getIdxName() + " " +t.getIndexes().get(0).delete );
			
		}*/
		sql = sql.toUpperCase();
		String indexdef = null;
		System.out.println("in method");
		//loadTables();
		boolean breakk = false;
		Table table = null;
		Index index = null;
		int tabIndex = 0;
		int indexI = 0;
		System.out.println(sql.split(" ")[2]);
		Table tav = new Table(sql.split(" ")[2]);
		for(Table t: tables) {
			indexI = 0;
			for(Index i: t.getIndexes()) {
				
				if(i.getIdxName().equalsIgnoreCase(sql.split(" ")[2])) {
					breakk = true;
					tav = t;
					index = i;
					//tables.get(tabIndex).deleteIndex(i);
					tables.get(tabIndex).setNumIndexes(t.getNumIndexes() - 1);
					tables.get(tabIndex).getIndexes().get(indexI).delete = true;
					//tav.setNumIndexes(t.getNumIndexes() - 1);
					//tav.getIndexes().get(indexI).delete = true;
					break;
				} indexI++;
				
			}if(breakk) {
				break;
			} tabIndex++;
		} if(!breakk) {
			System.out.println();
			throw new DbmsError("Index is not available!!");
		}	System.out.println(tables.get(tabIndex).getTableName());
		
		
		//ArrayList<String> ret = new ArrayList<String> ();
//new DBMS().storeTableFile(tav);
		//for(Table t: tables)
	//new DBMS().storeTableFile(t);
//loadTables();
//Thread.sleep(1000);
//ret.add(ageg);
		//ret.add(TABLE_FOLDER_NAME+"/"+table.getTableName()+TABLE_FILE_EXT);
		//return ret;
		
		//f1.
		//loadTables();
		System.out.println("DROP DONE");
	}
	private void createIndex(String sql ) throws Exception {
		// TODO Auto-generated method stub
		//loadTables();
		ArrayList<String> tokens = new ArrayList<String> ();
		StringTokenizer s = new StringTokenizer(sql);
				//System.out.println(tokens);
		while(s.hasMoreTokens()) {
			tokens.add(s.nextToken());
		}
		//System.out.println(tokens);
		//System.out.println(tokens.get(tokens.indexOf("INDEX") + 1));
		
		Index index = new Index(tokens.get(tokens.indexOf("INDEX") + 1));
		ArrayList<String> cols = new ArrayList<String>();
		String tableName = tokens.get(tokens.indexOf("ON") + 1);
		String indexName = tokens.get(tokens.indexOf("INDEX") + 1);
		//System.out.println(indexName + "indexName");
		Index ind = new Index(indexName);
		//System.out.println(tableName + "Table name");
		for(int i = tokens.indexOf("(") + 1; i < tokens.size() - 1; i+= 2) {
			if(tokens.get(i).equals(",")) { i++; }
			StringBuffer sb = new StringBuffer();
			sb.append(tokens.get(i));
			if(tokens.get(i + 1).equals(",") || tokens.get(i+1).equals(")")) {
				//if(sb.toString().trim().length() != 0) 
					cols.add(sb.toString());
				//sb = new StringBuffer();
			} else if (!(tokens.get(i).equals(","))){
				//System.out.println("HERE");
				sb.append(" ").append(tokens.get(i + 1));
				//if(sb.toString().trim().length() != 0) 
					cols.add(sb.toString());
			}
		}//System.out.println(cols);
		ArrayList<Boolean> desc = new ArrayList<Boolean> ();
		for(int i = 0; i < cols.size(); i++) {
			String s1[] = cols.get(i).split(" ");
			if (s1.length == 1) {
				desc.add(false);
			} else {
				if (s1[1].equalsIgnoreCase("DESC")) {
					desc.add(true);
				} else if (s1[1].equalsIgnoreCase("ASC")){
					desc.add(false);
				} else {
					throw new Exception("Syntax error in the statement");
				}
			}
		}
		boolean fileFound = false;
		Table table = null;
		for(Table t: tables) {
			if(t.getTableName().equalsIgnoreCase(tableName)) {
				fileFound = true;
				table = t;
				break;
			}
		}
		boolean indexExists = false;
		//for (Index i: index) {
			
		//}
		String IndexFileName = "";
		if (sql.split(" ")[1].equalsIgnoreCase("UNIQUE")) {
			IndexFileName = sql.split(" ")[5].concat(sql.split(" ")[3]).concat(".idx");
			/*File f = new File(IndexFileName);
			if(f.exists()) {
				throw new Exception("Index already exists!!");
			}*/
		} else if (sql.split(" ")[1].equalsIgnoreCase("INDEX")) {
			IndexFileName = sql.split(" ")[4].concat(sql.split(" ")[2]).concat(".idx");
			
		}
		
		
		/*File f = new File(TABLE_FOLDER_NAME);
		//System.out.println(IndexFileName);
		//System.out.println(f.isDirectory() + " is directory method output");
		File [] f1 = f.listFiles();
		for (File file : f1) {
			if (file.getName().equalsIgnoreCase(IndexFileName)) {
				indexExists = true;
			}
		}*/
		//boolean dupindex = false;
		//int flag = 1;
		//String stab = tableName;
		//Table tat = new Table(stab);
		//System.out.println(tables.indexOf(tat));
		//Table ter = tables.get(tables.indexOf(tat));
		for (Table ta: tables) {
			for(Index i : ta.getIndexes()) {
				//System.out.println(i.getIdxName() + "idx of " + ta.getTableName());
				if(i.getIdxName().equalsIgnoreCase(indexName) && i.delete == false 
						//&& ta.getTableName().trim().equalsIgnoreCase(tableName)
						) {
					//dupindex = true;
					//flag = 0;
					throw new DbmsError("Index "+ indexName +" already exists!!");
				}
				/*if(flag == 0) {
					break;
				}*/
			}
			
		}
		
		if(!fileFound) {
			//System.out.println("Table "+ tableName + " does not exists!..");
			throw new DbmsError("Table "+ tableName + " does not exists!..");
		} else if(indexExists) {
			//vikki 2210
			throw new DbmsError("Index "+ IndexFileName +" already exists!!");
		} /*else if(dupindex) {
			throw new DbmsError("Index "+ indexName +" already exists!!");
		}*/
		
		// else if for duplicate column definition
			else {
			//Table t = tables.get(tables.indexOf(tableName));
			//System.out.println(t.getData());
			//System.out.println(table.getData() );
			//System.out.println("Table data table.getData()");
			//System.out.println(table.getNumColumns());
			//System.out.println();
			ArrayList<Integer> colIndex = new ArrayList<Integer> ();
			for (int i = 0; i < cols.size(); i++) {
				for(int j = 0; j < table.getNumColumns(); j++) {
					//if(!desc.get(i)) {
						if(cols.get(i).split(" ")[0].equalsIgnoreCase(table.getColumns().get(j).getColName())) {
							//colIndex.set(i, new Integer(j));
							//System.out.println(new Integer(j) + cols.get(i));
							colIndex.add(i,new Integer(j));
						}
					/*} else {
						String temp = cols.get(i).split(" ")[0];
						if(temp.equalsIgnoreCase(table.getColumns().get(j).getColName())) {
							//colIndex.set(i, new Integer(j));
							System.out.println(new Integer(j) + temp);
							colIndex.add(i,new Integer(j));
						} 
					}*/
				}
			}
			//System.out.println(desc);
			//System.out.println(colIndex);
			
			ArrayList<String> appendString = new ArrayList<String>();
			for(int i = 0; i < desc.size(); i++) {
				String de = "A";
				if (desc.get(i).booleanValue()) de = "D";
				Integer  x = colIndex.get(i) + 1;
				String firstValue = x.toString();
				appendString.add(firstValue.concat(de));
			}
			//System.out.println(appendString);
			StringBuffer ab = new StringBuffer();
			for(String ssss: appendString) {
				ab.append(ssss).toString();
				ab.append(" ");
			}
			String appendStr = ab.toString().trim();
			//System.out.println(sql);
			Boolean isUnique = false;
			//String indexName = sql.split(" ")[2];
			if(sql.toUpperCase().contains("UNIQUE"))  { isUnique = true; }
			StringBuffer indexfileline1 = new StringBuffer(indexName.concat(" ").concat(isUnique.toString()));
			for(String sa: appendString) {
				indexfileline1.append(" ");
				indexfileline1.append(sa);
				
			}
			//System.out.println(appendStr + " appendStr");
			//System.out.println(indexfileline1);
			//System.out.println(tableName);
			//File tabfile = new File(tableName.concat(".tab"));
			//ArrayList<String> filecontent = tabfile.canRead();
			java.util.List<String> filecontent = //new java.util.ArrayList<String> ();
					Files.readAllLines(Paths.get(TABLE_FOLDER_NAME+"/"+tableName+TABLE_FILE_EXT));
			/*int aaa = 0;
			for (String sim: filecontent) {
				//System.out.println(sim.charAt(0) + " INDEX " + aaa );
				aaa++;
			}*/
			
			//System.out.println(cols.size() + "colssize");
			int noofcols = new Integer(filecontent.get(0));
			int maxlimit = noofcols + new Integer(filecontent.get(noofcols+1)) + 1;
			ArrayList<String> indexdef = new ArrayList<String>();
			
			for(int counter = noofcols + 2; counter <= maxlimit; counter++ ) {
				//System.out.println(filecontent.get(counter));
				String sp [] = filecontent.get(counter).split(" ");
				StringBuffer inte = new StringBuffer();
				for (int i = 2; i < sp.length; i++) {
					inte.append(sp[i]);
					inte.append(" ");
				}
				//filecontent.get(counter).
				indexdef.add(inte.toString().trim());
			}
			//System.out.println(indexdef);
			//System.out.println(appendStr);
			/*for(String saa: indexdef) {
				if(saa.equalsIgnoreCase(appendStr)) {
					throw new DbmsError("Index definition is duplicate! Please check the column combinations..");
				}
			}*/
			//System.out.println(table.getColumns().get(0).getColName());
			int noOfIndexes = cols.size();
			
			//System.out.println(cols + " cols");
			//System.out.println(indexdef + " indexdef");
			//System.out.println(appendStr + " appendStr");
			ArrayList<String> colArray = new ArrayList<String> ();
			ArrayList<String> sort = new ArrayList<String> ();
			for(String saa : appendStr.split(" ")) {
				colArray.add(""+saa.charAt(0));
				sort.add(""+saa.charAt(1));
			}
			//System.out.println(colArray + " colArray");
			//System.out.println(sort + " sort");
			//System.out.println(table.getColumns().get(1).getColName());
			//table.getColumns().get(0).
			/*for(String sa :  table.getData()) {
				System.out.println(sa);
			}*/
			int col = 0;
			ArrayList<String> fi = new ArrayList<String> ();
			//ArrayList<ArrayList<String>> fi = new ArrayList<ArrayList<String>>();
				/*System.out.println("AFAFSA");
				for(String afafg : table.getData().get(0).split(" +")) {
					System.out.println(afafg);
				}*/
				int i = 1;
			for(String sa :  table.getData()) {
				StringBuffer aa1 = new StringBuffer();
				for(String abc : colArray) {
					
					//System.out.println("In for ");
				String aa[] = sa.split(" +");
				//System.out.println(aa[2] + " aa[3]");
				
				int colIndexa  = Integer.parseInt(abc);
				//System.out.println(colIndexa);
				//System.out.println(aa[colIndexa]);
				aa1.append(aa[colIndexa]).append(" ");
				
				
				}
				
				fi.add("" +i+ " "+aa1.toString());
				i++;
			} /*System.out.println(fi + " Fi");
			System.out.println(sort);
			System.out.println(filecontent);
			*/
			ArrayList<Character> datatype = new ArrayList<Character> ();
			ArrayList<Integer> length = new ArrayList<Integer> ();
			int noofcolus = Integer.parseInt(filecontent.get(0));
			//System.out.println(cols);
			for(String ca : cols) {
				String c = ca.split(" ")[0];
				for(int ia = 1; ia <= noofcolus; ia++) {
					//System.out.println(c + "EFCSAFEGEAGEGE");
					if(filecontent.get(ia).split(" ")[0].equalsIgnoreCase(c) ) {
						datatype.add(filecontent.get(ia).split(" ")[1].charAt(0));
						if(filecontent.get(ia).split(" " )[1].length() > 1)
						length.add(Integer.parseInt(filecontent.get(ia).split(" " )[1].substring(1)));
						else 
							length.add(10);
					}
				}
			}
		/*	System.out.println(fi + " fi");
			System.out.println(sort + " sort");
			System.out.println(datatype + " datatype");
			System.out.println(length + " length");
			*///this.sort(fi,sort,datatype,length);
			//return hashmap<string,integer>
			if(sort.size() >= 1) { // remove = if there is a need to change logic for single column index
			ArrayList<String> merged = new ArrayList<String>();
			for(String fa: fi) {
				StringBuffer sbuf = new StringBuffer();
				String aaaaa [] = fa.split(" ");
				for(int cnt = 1; cnt < aaaaa.length; cnt++) {
					if(datatype.get(cnt - 1).equals('C')) { //character
						if (aaaaa[cnt].length() < length.get(cnt - 1)) { //len start
							if(sort.get(cnt - 1).equalsIgnoreCase("A")) {
								aaaaa[cnt] = String.format("%1$-"+length.get(cnt-1)+"s",aaaaa[cnt]);
							} else { //TODO desc
								String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; String lowercase = "abcdefghijklmnopqrstuvwxyz";
								String temp = aaaaa[cnt];
								StringBuffer sss = new StringBuffer();
								for(int it = 0; it < temp.length(); it++){
									for(int j = 0; j < lowercase.length(); j++) {
										if(temp.charAt(it) == lowercase.charAt(j) ) {
											sss.append(lowercase.charAt(25-lowercase.indexOf(temp.charAt(it))));
											break;
										} else if(temp.charAt(it) == UPPERCASE.charAt(j)) {
											sss.append(UPPERCASE.charAt(25-UPPERCASE.indexOf(temp.charAt(it))));
											break;
										}
										}
								} aaaaa[cnt] =  String.format("%1$-"+length.get(cnt - 1)+"s",sss.toString());
							} //desc end
						} //len end
					} /*char end */else { // number
						if (aaaaa[cnt].length() < length.get(cnt - 1)) { // len start
							if(sort.get(cnt - 1).equalsIgnoreCase("A")) { //asc start
								aaaaa[cnt] = String.format("%0"+length.get(cnt - 1)+"d",Integer.parseInt(aaaaa[cnt]));
							}/* asc end */ else { //TODO
								int len = length.get(cnt - 1);
								StringBuffer temp = new StringBuffer();
								for(int abcd = 0; abcd < len; abcd++) {
									temp.append("9");
								}
								long tempval = Long.parseLong(temp.toString()) - Integer.parseInt(aaaaa[cnt]);
								aaaaa[cnt] = String.format("%0"+length.get(cnt - 1)+"d",tempval);
								} //desc end
						} //len end
					} //number end
					sbuf.append(aaaaa[cnt]);
				}//System.out.println(aaaaa[0] + " "+ aaaaa[1] + aaaaa[2]);
				merged.add(sbuf.toString().concat(" ").concat(aaaaa[0])); //aaaaa[0]
			} // loop end for after merge
			//System.out.println(merged);
			Collections.sort(merged);
			//System.out.println(merged);
			//System.out.println(indexName);
			
			ind.setIsUnique(isUnique);
			//System.out.println(appendString + " appendString");
			//ArrayList<Index.IndexKeyDef> ikda = new ArrayList<Index.IndexKeyDef> ();
			int colidxposinc = 0;
			for(String sat: appendString) {
				//Index x = new Index();
				Index.IndexKeyDef ikd =  ind.new IndexKeyDef();
				ikd.idxColPos = ++ colidxposinc;
				ikd.colId = Integer.parseInt(""+sat.charAt(0));
				if(sat.charAt(1) == 'D')
				ikd.descOrder = true;
				ind.addIdxKey(ikd);
			}
			//System.out.println(merged.get(0).split(" +")[1] + " split[1]");
			ArrayList<String> sunique = new ArrayList<String> ();
			for(String me: merged) {
				//System.out.println(me.length());
				Index.IndexKeyVal ikv = ind.new IndexKeyVal();
				String aab [] = me.split(" ");
				ikv.rid = Integer.parseInt(aab[aab.length-1]);
				
				//System.out.println(me.split(" +")[1].length());
				int te = aab[aab.length - 1].length();
				//System.out.println(te + "teeeeeeeeeeeee");
				//System.out.println(me.substring(0, me.length() - te - 1).length());
				ikv.value = me.substring(0, me.length() - te - 1);//me.split("\\s+")[0];//clarify on quotes
				//System.out.println(ikv.value.length() + " lengtthhhhhhhhhhh") ;
				//System.out.println("ikv value" + ikv.value); 
				sunique.add(ikv.value);
				ind.addKey(ikv);
				
				
				
				
				
			} 
			if(isUnique) { //handle unique index
				Set<String> set = new HashSet();
				for(String sagfea: sunique) {
					set.add(sagfea);
				}
				//System.out.println("isunique test" + (set.size() == sunique.size()));
				boolean isUniqueNotViolated = set.size() == sunique.size();
				if(isUniqueNotViolated == false) {
					throw new DbmsError("Unique index violation, keys have duplicate values");
				}
			}
			} 
			//ind.id
			/*System.out.println(table.getNumIndexes());
			System.out.println(ind.getIdxKey().get(0).colId);
			*///System.out.println(ind.getKeys().get(0).rid);
			//table.setNumIndexes(table.getNumIndexes() + 1);
			
			table.addIndex(ind);
			new DBMS().storeTableFile(table);//(vikki)
			}
		//table.addIndex(ind);
		
		//chummaa - 
	//	loadTables();//(vikki)
		System.out.println("CREATE DONE");
		
	}
	
	
	/*public void sort(ArrayList<String> data, ArrayList<String> order, ArrayList<Character> datatype, ArrayList<Integer> length) {
		ArrayList<Character> lowercase = new ArrayList<Character> ();
		int i = 0;
		for (char a = 'a'; a <= 'z'; a++,i++){
			lowercase.add(a);
		}
		char [] uppercase = new char[26];
		i = 0;
		for (char a = 'A'; a <= 'Z'; a++,i++){
			uppercase[i] = a;
		}
		//char ab = 'F';
		//String aa = String.valueOf(ab);
		String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lowercase = "abcdefghijklmnopqrstuvwxyz";
		//System.out.println(x.charAt(25-x.indexOf('M')));
		int noOfCols = data.get(0).split(" ").length - 1;
		System.out.println(noOfCols);
		ArrayList<String > enc = new ArrayList<String> ();
		if (noOfCols == 1) {
			if(order.get(0).equals("A")) {
				//split and sort
				System.out.println(data);
				ArrayList <String> enc1 = new ArrayList<String> ();
				for(String s: data) {
					enc1.add(s.split(" ")[1]);
				}
				Collections.sort(enc1);
				ArrayList<String> index = new ArrayList<String> ();
				for(String Enc: enc1) {
					StringBuffer sb = new StringBuffer();
					for(String FI :data) {
						if (Enc.equals(FI.split(" ")[1])) {
							sb.append(FI.split(" ")[0]).append(" ").append(Enc);
							break;
						}
						
					} index.add(sb.toString());
				}
				System.out.println(index + " index");
				System.out.println(length + " length");
			} else {
				if(datatype.get(0) == 'C')  {
				for(String s: data) {
					String val = s.split(" ")[1];
					//System.out.println(val);
					StringBuffer sss = new StringBuffer();
					System.out.println(val + "val");
					for(int i = 0; i < val.length(); i++) {
						for(int j = 0; j < lowercase.length(); j++) {
						if(val.charAt(i) == lowercase.charAt(j) ) {
							sss.append(lowercase.charAt(25-lowercase.indexOf(val.charAt(i))));
							break;
						} else if(val.charAt(i) == UPPERCASE.charAt(j)) {
							sss.append(UPPERCASE.charAt(25-UPPERCASE.indexOf(val.charAt(i))));
							break;
						}
						}
					} //System.out.println(sss.toString());
						enc.add(sss.toString());
				} System.out.println(data + " data");
				System.out.println(enc + " enc");
				
				int ab = 0; 
				ArrayList<String> finalD = new ArrayList<String> ();
				for(String s : data) {
					StringBuffer ssss = new StringBuffer();
					ssss.append(s.split(" ")[0]).append(" ").append(enc.get(ab));
					//System.out.println();
					finalD.add(ssss.toString());
				ab++;
				}
				System.out.println(finalD + " finalD");
				TreeMap<String,String> hm = new TreeMap<String,String> ();
				for(String s : finalD) {
					hm.put(s.split(" ")[1], s.split(" ")[0]);
				}
				
				System.out.println(hm);
				Collections.sort(enc);
				System.out.println(enc + " after sorting");
				ArrayList<String> index = new ArrayList<String> ();
				for(String Enc: enc) {
					StringBuffer sb = new StringBuffer();
					for(String FI :finalD) {
						if (Enc.equals(FI.split(" ")[1])) {
							sb.append(FI.split(" ")[0]).append(" ").append(Enc);
							break;
						}
						
					} index.add(sb.toString());
				}
				System.out.println(index + " index");
				System.out.println(length.get(0));
				} //end of datatype = c
				
				else {
					System.out.println("N ELSE");
					System.out.println(length.get(0));
					System.out.println(data);
					ArrayList<Integer> datatosort = new ArrayList<Integer> ();
					for(String s: data) {
						datatosort.add(Integer.parseInt(s.split(" ")[1]));
					}
					//Collections.reverse(datatosort);
					
					System.out.println(datatosort + " datatosort");
					System.out.println(data + " data");
					ArrayList<String> fd = new ArrayList<String>();
					for(int a: datatosort) {
						for(String s: data) {
							if(s.split(" ")[1].equals(""+a)) {
								fd.add(s.split(" ")[0].concat(" ").concat(s.split(" ")[1]));
								break;
							}
							//fd.add();
						} 
					}System.out.println(fd + " fd");
				}
			}
		}
	}*/

	/**
	 * Loads tables to memory
	 * 
	 * @throws Exception
	 */
	private void loadTables() throws Exception {
		// Get all the available tables in the "tables" directory
		File tableDir = new File(TABLE_FOLDER_NAME);
		if (tableDir.exists() && tableDir.isDirectory()) {
			for (File tableFile : tableDir.listFiles()) {
				// For each file check if the file extension is ".tab"
				String tableName = tableFile.getName();
				int periodLoc = tableName.lastIndexOf(".");
				String tableFileExt = tableName.substring(tableName
						.lastIndexOf(".") + 1);
				if (tableFileExt.equalsIgnoreCase("tab")) {
					// If it is a ".tab" file, create a table structure
					Table table = new Table(tableName.substring(0, periodLoc));
					Scanner in = new Scanner(tableFile);

					try {
						// Read the file to get Column definitions
						int numCols = Integer.parseInt(in.nextLine());

						for (int i = 0; i < numCols; i++) {
							StringTokenizer tokenizer = new StringTokenizer(
									in.nextLine());
							String name = tokenizer.nextToken();
							String type = tokenizer.nextToken();
							boolean nullable = Boolean.parseBoolean(tokenizer
									.nextToken());
							switch (type.charAt(0)) {
							case 'C':
								table.addColumn(new Column(i + 1, name,
										Column.ColType.CHAR, Integer
												.parseInt(type.substring(1)),
										nullable));
								break;
							case 'I':
								table.addColumn(new Column(i + 1, name,
										Column.ColType.INT, 4, nullable));
								break;
							default:
								break;
							}
						}

						// Read the file for index definitions
						int numIdx = Integer.parseInt(in.nextLine());
						for (int i = 0; i < numIdx; i++) {
							StringTokenizer tokenizer = new StringTokenizer(
									in.nextLine());
							//vikki
							String s = tokenizer.nextToken();
							System.out.println(s + "S");
							Index index = new Index(s);
							index.setIsUnique(Boolean.parseBoolean(tokenizer
									.nextToken()));

							int idxColPos = 1;
							while (tokenizer.hasMoreTokens()) {
								String colDef = tokenizer.nextToken();
								Index.IndexKeyDef def = index.new IndexKeyDef();
								def.idxColPos = idxColPos;
								def.colId = Integer.parseInt(colDef.substring(
										0, colDef.length() - 1));
								switch (colDef.charAt(colDef.length() - 1)) {
								case 'A':
									def.descOrder = false;
									break;
								case 'D':
									def.descOrder = true;
									break;
								default:
									break;
								}

								index.addIdxKey(def);
								idxColPos++;
							}

							table.addIndex(index);
							//System.out.println("H");
							loadIndex(table, index);
						}

						// Read the data from the file
						int numRows = Integer.parseInt(in.nextLine());
						for (int i = 0; i < numRows; i++) {
							table.addData(in.nextLine());
						}
						
						// Read RUNSTATS from the file
						while(in.hasNextLine()) {
							String line = in.nextLine();
							StringTokenizer toks = new StringTokenizer(line);
							if(toks.nextToken().equals("STATS")) {
								String stats = toks.nextToken();
								if(stats.equals("TABCARD")) {
									table.setTableCard(Integer.parseInt(toks.nextToken()));
								} else if (stats.equals("COLCARD")) {
									Column col = table.getColumns().get(Integer.parseInt(toks.nextToken()));
									col.setColCard(Integer.parseInt(toks.nextToken()));
									col.setHiKey(toks.nextToken());
									col.setLoKey(toks.nextToken());
								} else {
									throw new DbmsError("Invalid STATS.");
								}
							} else {
								throw new DbmsError("Invalid STATS.");
							}
						}
					} catch (DbmsError ex) {
						throw ex;
					} catch (Exception ex) {
						throw new DbmsError("Invalid table file format.");
					} finally {
						in.close();
					}
					tables.add(table);
				}
			}
		} else {
			throw new FileNotFoundException(
					"The system cannot find the tables directory specified.");
		}
		//System.out.println("CREATE DONE");
	}

	/**
	 * Loads specified table to memory
	 * 
	 * @throws DbmsError
	 */
	private void loadIndex(Table table, Index index) throws DbmsError {
		try {
			Scanner in = new Scanner(new File(TABLE_FOLDER_NAME,
					table.getTableName() + index.getIdxName() + INDEX_FILE_EXT));
			String def = in.nextLine();
			String rows = in.nextLine();

			while (in.hasNext()) {
				String line = in.nextLine();
				Index.IndexKeyVal val = index.new IndexKeyVal();
				val.rid = Integer.parseInt(new StringTokenizer(line)
						.nextToken());
				val.value = line.substring(line.indexOf("'") + 1,
						line.lastIndexOf("'"));
				index.addKey(val);
			}
			in.close();
		} catch (Exception ex) {
			throw new DbmsError("Invalid index file format.");
		}
	}

	/**
	 * CREATE TABLE
	 * <table name>
	 * ( <col name> < CHAR ( length ) | INT > <NOT NULL> ) ;
	 * 
	 * @param sql
	 * @param tokenizer
	 * @throws Exception
	 */
	private void createTable(String sql, StringTokenizer tokenizer)
			throws Exception {
		try {
			// Check the table name
			String tok = tokenizer.nextToken().toUpperCase();
			if (Character.isAlphabetic(tok.charAt(0))) {
				// Check if the table already exists
				for (Table tab : tables) {
					if (tab.getTableName().equals(tok) && !tab.delete) {
						throw new DbmsError("Table " + tok
								+ "already exists. '" + sql + "'.");
					}
				}

				// Create a table instance to store data in memory
				Table table = new Table(tok.toUpperCase());

				// Check for '('
				tok = tokenizer.nextToken();
				if (tok.equals("(")) {
					// Look through the column definitions and add them to the
					// table in memory
					boolean done = false;
					int colId = 1;
					while (!done) {
						tok = tokenizer.nextToken();
						if (Character.isAlphabetic(tok.charAt(0))) {
							String colName = tok;
							Column.ColType colType = Column.ColType.INT;
							int colLength = 4;
							boolean nullable = true;

							tok = tokenizer.nextToken();
							if (tok.equalsIgnoreCase("INT")) {
								// use the default Column.ColType and colLength

								// Look for NOT NULL or ',' or ')'
								tok = tokenizer.nextToken();
								if (tok.equalsIgnoreCase("NOT")) {
									// look for NULL after NOT
									tok = tokenizer.nextToken();
									if (tok.equalsIgnoreCase("NULL")) {
										nullable = false;
									} else {
										throw new NoSuchElementException();
									}

									tok = tokenizer.nextToken();
									if (tok.equals(",")) {
										// Continue to the next column
									} else if (tok.equalsIgnoreCase(")")) {
										done = true;
									} else {
										throw new NoSuchElementException();
									}
								} else if (tok.equalsIgnoreCase(",")) {
									// Continue to the next column
								} else if (tok.equalsIgnoreCase(")")) {
									done = true;
								} else {
									throw new NoSuchElementException();
								}
							} else if (tok.equalsIgnoreCase("CHAR")) {
								colType = Column.ColType.CHAR;

								// Look for column length
								tok = tokenizer.nextToken();
								if (tok.equals("(")) {
									tok = tokenizer.nextToken();
									try {
										colLength = Integer.parseInt(tok);
									} catch (NumberFormatException ex) {
										throw new DbmsError(
												"Invalid table column length for "
														+ colName + ". '" + sql
														+ "'.");
									}

									// Check for the closing ')'
									tok = tokenizer.nextToken();
									if (!tok.equals(")")) {
										throw new DbmsError(
												"Invalid table column definition for "
														+ colName + ". '" + sql
														+ "'.");
									}

									// Look for NOT NULL or ',' or ')'
									tok = tokenizer.nextToken();
									if (tok.equalsIgnoreCase("NOT")) {
										// Look for NULL after NOT
										tok = tokenizer.nextToken();
										if (tok.equalsIgnoreCase("NULL")) {
											nullable = false;

											tok = tokenizer.nextToken();
											if (tok.equals(",")) {
												// Continue to the next column
											} else if (tok
													.equalsIgnoreCase(")")) {
												done = true;
											} else {
												throw new NoSuchElementException();
											}
										} else {
											throw new NoSuchElementException();
										}
									} else if (tok.equalsIgnoreCase(",")) {
										// Continue to the next column
									} else if (tok.equalsIgnoreCase(")")) {
										done = true;
									} else {
										throw new NoSuchElementException();
									}
								} else {
									throw new DbmsError(
											"Invalid table column definition for "
													+ colName + ". '" + sql
													+ "'.");
								}
							} else {
								throw new NoSuchElementException();
							}

							// Everything is ok. Add the column to the table
							table.addColumn(new Column(colId, colName, colType,
									colLength, nullable));
							colId++;
						} else {
							// if(colId == 1) {
							throw new DbmsError(
									"Invalid table column identifier " + tok
											+ ". '" + sql + "'.");
							// }
						}
					}

					// Check for the semicolon
					tok = tokenizer.nextToken();
					if (!tok.equals(";")) {
						throw new NoSuchElementException();
					}

					// Check if there are more tokens
					if (tokenizer.hasMoreTokens()) {
						throw new NoSuchElementException();
					}

					if (table.getNumColumns() == 0) {
						throw new DbmsError(
								"No column descriptions specified. '" + sql
										+ "'.");
					}

					// The table is stored into memory when this program exists.
					tables.add(table);

					out.println("Table " + table.getTableName()
							+ " was created.");
				} else {
					throw new NoSuchElementException();
				}
			} else {
				throw new DbmsError("Invalid table identifier " + tok + ". '"
						+ sql + "'.");
			}
		} catch (NoSuchElementException ex) {
			throw new DbmsError("Invalid CREATE TABLE statement. '" + sql
					+ "'.");
		}
	}

	/**
	 * INSERT INTO
	 * <table name>
	 * VALUES ( val1 , val2, .... ) ;
	 * 
	 * @param sql
	 * @param tokenizer
	 * @throws Exception
	 */
	private void insertInto(String sql, StringTokenizer tokenizer)
			throws Exception {
		try {
			String tok = tokenizer.nextToken();
			if (tok.equalsIgnoreCase("INTO")) {
				tok = tokenizer.nextToken().trim().toUpperCase();
				Table table = null;
				for (Table tab : tables) {
					if (tab.getTableName().equals(tok)) {
						table = tab;
						break;
					}
				}

				if (table == null) {
					throw new DbmsError("Table " + tok + " does not exist.");
				}

				tok = tokenizer.nextToken();
				if (tok.equalsIgnoreCase("VALUES")) {
					tok = tokenizer.nextToken();
					if (tok.equalsIgnoreCase("(")) {
						tok = tokenizer.nextToken();
						String values = String.format("%3s", table.getData()
								.size() + 1)
								+ " ";
						int colId = 0;
						boolean done = false;
						while (!done) {
							if (tok.equals(")")) {
								done = true;
								break;
							} else if (tok.equals(",")) {
								// Continue to the next value
							} else {
								if (colId == table.getNumColumns()) {
									throw new DbmsError(
											"Invalid number of values were given.");
								}

								Column col = table.getColumns().get(colId);

								if (tok.equals("-") && !col.isColNullable()) {
									throw new DbmsError(
											"A NOT NULL column cannot have null. '"
													+ sql + "'.");
								}

								if (col.getColType() == Column.ColType.INT) {
									try {
										if(!tok.equals("-")) {
											int temp = Integer.parseInt(tok);
										}
									} catch (Exception ex) {
										throw new DbmsError(
												"An INT column cannot hold a CHAR. '"
														+ sql + "'.");
									}

									tok = String.format("%10s", tok.trim());
								} else if (col.getColType() == Column.ColType.CHAR) {
									int length = tok.length();
									if (length > col.getColLength()) {
										throw new DbmsError(
												"A CHAR column cannot exceede its length. '"
														+ sql + "'.");
									}

									tok = String.format(
											"%-" + col.getColLength() + "s",
											tok.trim());
								}

								values += tok + " ";
								colId++;
							}
							tok = tokenizer.nextToken().trim();
						}

						if (colId != table.getNumColumns()) {
							throw new DbmsError(
									"Invalid number of values were given.");
						}

						// Check for the semicolon
						tok = tokenizer.nextToken();
						if (!tok.equals(";")) {
							throw new NoSuchElementException();
						}

						// Check if there are more tokens
						if (tokenizer.hasMoreTokens()) {
							throw new NoSuchElementException();
						}

						// insert the value to table
						table.addData(values);
						out.println("One line was saved to the table. "
								+ table.getTableName() + ": " + values);
					} else {
						throw new NoSuchElementException();
					}
				} else {
					throw new NoSuchElementException();
				}
			} else {
				throw new NoSuchElementException();
			}
		} catch (NoSuchElementException ex) {
			throw new DbmsError("Invalid INSERT INTO statement. '" + sql + "'.");
		}
	}

	/**
	 * DROP TABLE
	 * <table name>
	 * ;
	 * 
	 * @param sql
	 * @param tokenizer
	 * @throws Exception
	 */
	private void dropTable(String sql, StringTokenizer tokenizer)
			throws Exception {
		try {
			// Get table name
			String tableName = tokenizer.nextToken();

			// Check for the semicolon
			String tok = tokenizer.nextToken();
			if (!tok.equals(";")) {
				throw new NoSuchElementException();
			}

			// Check if there are more tokens
			if (tokenizer.hasMoreTokens()) {
				throw new NoSuchElementException();
			}

			// Delete the table if everything is ok
			boolean dropped = false;
			for (Table table : tables) {
				if (table.getTableName().equalsIgnoreCase(tableName)) {
					table.delete = true;
					dropped = true;
					break;
				}
			}

			if (dropped) {
				out.println("Table " + tableName + " was dropped.");
			} else {
				throw new DbmsError("Table " + tableName + "does not exist. '" + sql + "'."); 
			}
		} catch (NoSuchElementException ex) {
			throw new DbmsError("Invalid DROP TABLE statement. '" + sql + "'.");
		}

	}

	private void printRunstats(String tableName) {
		for (Table table : tables) {
			if (table.getTableName().equals(tableName)) {
				out.println("TABLE CARDINALITY: " + table.getTableCard());
				for (Column column : table.getColumns()) {
					out.println(column.getColName());
					out.println("\tCOLUMN CARDINALITY: " + column.getColCard());
					out.println("\tCOLUMN HIGH KEY: " + column.getHiKey());
					out.println("\tCOLUMN LOW KEY: " + column.getLoKey());
				}
				break;
			}
		}
	}

	private void storeTableFile(Table table) throws FileNotFoundException {
		File tableFile = new File(TABLE_FOLDER_NAME, table.getTableName()
				+ TABLE_FILE_EXT);

		// Delete the file if it was marked for deletion
		if (table.delete) {
			try {
				tableFile.delete();
			} catch (Exception ex) {
				out.println("Unable to delete table file for "
						+ table.getTableName() + ".");
			}
			
			// Delete the index files too
			for (Index index : table.getIndexes()) {
				File indexFile = new File(TABLE_FOLDER_NAME, table.getTableName()
						+ index.getIdxName() + INDEX_FILE_EXT);
				
				try {
					indexFile.delete();
				} catch (Exception ex) {
					out.println("Unable to delete table file for "
							+ indexFile.getName() + ".");
				}
			}
		} else {
			//System.out.println("in else"); //vikki
			// Create the table file writer
			PrintWriter out = new PrintWriter(tableFile);

			// Write the column descriptors
			out.println(table.getNumColumns());
			for (Column col : table.getColumns()) {
				if (col.getColType() == Column.ColType.INT) {
					out.println(col.getColName() + " I " + col.isColNullable());
				} else if (col.getColType() == Column.ColType.CHAR) {
					out.println(col.getColName() + " C" + col.getColLength()
							+ " " + col.isColNullable());
				}
			}

			// Write the index info
			out.println(table.getNumIndexes());
			for (Index index : table.getIndexes()) {
				if(!index.delete) {
					String idxInfo = index.getIdxName() + " " + index.getIsUnique()
							+ " ";

					for (Index.IndexKeyDef def : index.getIdxKey()) {
						idxInfo += def.colId;
						if (def.descOrder) {
							idxInfo += "D ";
						} else {
							idxInfo += "A ";
						}
					}
					out.println(idxInfo);
				}
			}

			// Write the rows of data
			out.println(table.getData().size());
			for (String data : table.getData()) {
				out.println(data);
			}

			// Write RUNSTATS
			out.println("STATS TABCARD " + table.getTableCard());
			for (int i = 0; i < table.getColumns().size(); i++) {
				Column col = table.getColumns().get(i);
				if(col.getHiKey() == null)
					col.setHiKey("-");
				if(col.getLoKey() == null)
					col.setLoKey("-");
				out.println("STATS COLCARD " + i + " " + col.getColCard() + " " + col.getHiKey() + " " + col.getLoKey());
			}
			
			out.flush();
			out.close();
		}

		// Save indexes to file
		for (Index index : table.getIndexes()) {

			File indexFile = new File(TABLE_FOLDER_NAME, table.getTableName()
					+ index.getIdxName() + INDEX_FILE_EXT);

			// Delete the file if it was marked for deletion
			if (index.delete) {
				try {
					indexFile.delete();
				} catch (Exception ex) {
					out.println("Unable to delete index file for "
							+ indexFile.getName() + ".");
				}
			} else {
				PrintWriter out = new PrintWriter(indexFile);
				String idxInfo = index.getIdxName() + " " + index.getIsUnique()
						+ " ";

				// Write index definition
				for (Index.IndexKeyDef def : index.getIdxKey()) {
					idxInfo += def.colId;
					if (def.descOrder) {
						idxInfo += "D ";
					} else {
						idxInfo += "A ";
					}
				}
				out.println(idxInfo);

				// Write index keys
				out.println(index.getKeys().size());
				for (Index.IndexKeyVal key : index.getKeys()) {
					String rid = String.format("%3s", key.rid);
					out.println(rid + " '" + key.value + "'");
				}

				out.flush();
				out.close();

			}
		}
	}
}
