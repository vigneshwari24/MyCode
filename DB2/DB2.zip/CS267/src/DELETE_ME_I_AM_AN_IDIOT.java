import java.awt.SplashScreen;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;

public class DELETE_ME_I_AM_AN_IDIOT {
	public static void main(String [] args) throws Exception {
		/*String input_str = "create index a on t1 ( name ) ; ";
		String input_uni_str = " create unique index a on t1 ( name ) ; ";
		//ArrayList<File> a = new ArrayList<File>();
		String IndexFileName = "";
		if (args[0].split(" ")[1].equalsIgnoreCase("UNIQUE")) {
			IndexFileName = args[0].split(" ")[5].concat(args[0].split(" ")[3]).concat(".idx");
			File f = new File(IndexFileName);
			if(f.exists()) {
				throw new Exception("Index already exists!!");
			}
		} else if (args[0].split(" ")[1].equalsIgnoreCase("INDEX")) {
			IndexFileName = args[0].split(" ")[4].concat(args[0].split(" ")[2]).concat(".idx");
			File f = new File(IndexFileName);
			if(f.exists()) {
				throw new Exception("Index already exists!!");
			}
		}
		for(String s : args[0].split(" ")) {
			System.out.println(s);
		}
		
		File f = new File("tables");
		System.out.println(IndexFileName);
		System.out.println(f.isDirectory() + " is directory method output");
		File [] f1 = f.listFiles();
		for (File file : f1) {
			if (file.getName().equalsIgnoreCase(IndexFileName)) {
				throw new Exception("Index already exists!!");
			}
		} 
		File f = new File("tables");
		File [] f1 = f.listFiles();
		for (File file : f1) {
			
			if (file.getName().startsWith("T1") && (file.getName().endsWith(".idx"))) {
				throw new Exception("Index already exists!!");
			}
		}
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(22);
		a.add(52);
		a.add(2255);
		a.add(6722);
		a.add(222);
		Collections.sort(a);
		System.out.println(a);
		Collections.reverse(a);
		System.out.println(a);
		String formatted = String.format("%010d", 4);
		String s= String.format("%1$-10s", "hi");
		System.out.println(s.length());
		System.out.println(formatted);
		//char
		 
		 
*/		String aaa = "tables/T1.tab".split("/")[1];
		System.out.println(aaa.substring(0, aaa.length() - 4));
		File f = new File("tables/T2.tab");	
		f.createNewFile();
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		ArrayList<String> filecontent = new ArrayList<String> ();
		String s; 
		//String s1 =br.readLine();
		while((s = br.readLine()) != null) {
			filecontent.add(s);
			
		}
		int noofcol = Integer.parseInt(filecontent.get(0));
		int index = Integer.parseInt(filecontent.get(noofcol + 1));
		int temp = index - 1;
		filecontent.set(noofcol+1, ""+temp);
		for(int i = noofcol + 1; i <= noofcol + index + 1; i++) {
			if(filecontent.get(i).trim().equals("X1 false 1A")) {
				//int temp = index - 1;
				//filecontent.add(i - 1, ""+temp);
				filecontent.remove(i);
				
				break;
				
				
				//int dec = filecontent
			}
		}
		fr.close();
		br.close();
		f.delete();
		System.out.println(filecontent);
		File f1 = new File("tables/c.tab");
		System.out.println(f1.exists());
		FileWriter fw = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fw);
		for(String a: filecontent) {
			if (!a.trim().equals("X1 false 1A")) {
				System.out.println(a);
			bw.write(a);
			bw.newLine(); }
		}
		bw.flush();
		fw.close();
		}
	int a() {
		//int x,y;
		
		
		return 0;
	}
}
