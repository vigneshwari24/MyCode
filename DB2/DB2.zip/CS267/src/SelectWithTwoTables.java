import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;



public class SelectWithTwoTables {
	boolean remove = false;
	boolean TCPFlag = false;
	Table t1,table2;
	PlanTable planTable = new PlanTable();
	ArrayList<Predicate> classPredicates;
	public PlanTable select(ArrayList<String> sqlarray, ArrayList<Table> table) {
		//////System.out.println("IN T2 tbl");
		ArrayList<String> LHS = new ArrayList<String>();
		ArrayList<String> operator = new ArrayList<String>();
		ArrayList<String> RHS = new ArrayList<String>();
		ArrayList<String> logical = new ArrayList<String>();
		int endindex = sqlarray.size() - 1;
		int andorCounter = 0;
		int orCounter = 0;
		ArrayList<String> intermediate = new ArrayList<String> ();
			for(int i = sqlarray.indexOf("WHERE") + 1; i <= endindex; i++) {
				if(sqlarray.get(i).equals("AND") || sqlarray.get(i).equals("OR")) {
					andorCounter++; 
					if(sqlarray.get(i).equals("OR")) orCounter++; //for in list transformation
				} 
				intermediate.add(sqlarray.get(i));
			}
			ArrayList<Integer> andorindex = new ArrayList<Integer>();
			int in = 0;
			//////System.out.println(intermediate + " intermediate");
			for(String s: intermediate) {
				if(s.equals("AND") || s.equals("OR")) {
					andorindex.add(in);
					logical.add(s);
				}	
				in++;
			}
			//////System.out.println(andorindex + " andorindex");
			int index = 0;
			for(int i = 0; i < intermediate.size(); i++ ) {
				LHS.add(intermediate.get(i));
				operator.add(intermediate.get(i + 1));
				StringBuffer sb = new StringBuffer();
				if(andorCounter > 0) {
					int a = i + 2;
					for(; a < andorindex.get(index); a++) {
						sb.append(intermediate.get(a));
					}
					RHS.add(sb.toString());
					index++;
					andorCounter--;
					i = a;
				} else {
					int a = i + 2;
					for(; a < intermediate.size(); a++) {
						sb.append(intermediate.get(a));
					}
					RHS.add(sb.toString());
					i = a;
					}
			}
		/*////System.out.println(LHS);
		////System.out.println(RHS);
		////System.out.println(logical);
		////System.out.println(operator);*/
		
		String lhsTable = LHS.get(0).split("\\.")[0];
		String rhsTable = RHS.get(0).split("\\.")[0];
		String lhs = LHS.get(0).split("\\.")[1];
		String rhs = RHS.get(0).split("\\.")[1];
		String joinLHS = "";
		String joinRHS = "";
		int joinloc = -1;
		for(int i = 0; i < LHS.size() ; i++) {
			//////System.out.println("TORF" + LHS.get(i).contains("."));
			if(LHS.get(i).contains(".") && RHS.get(i).contains(".")) {
				//////System.out.println("LHS RHS DOT CHECK");
				joinLHS = LHS.get(i);
				joinRHS = RHS.get(i);
				joinloc = i;
				if(LHS.get(i).split("\\.")[0].trim().equalsIgnoreCase(table.get(0).getTableName())) {
					t1 = table.get(0);
					table2 = table.get(1);
				}  else {
					t1 = table.get(1);
					table2 = table.get(0);
				}
				break;
			}
		}
		ArrayList<String> tempLHS = new ArrayList<String> ();
		ArrayList<String> tempRHS = new ArrayList<String> ();
		for(int i = 0; i < LHS.size(); i++) {
			if(i != joinloc) {
				tempLHS.add(LHS.get(i));
				tempRHS.add(RHS.get(i));
			}
		}
		/*////System.out.println(LHS + " " +RHS);
		////System.out.println(joinLHS + " " + joinRHS);
		////System.out.println(tempLHS + " " + tempRHS);
		*/if(tempLHS.contains(joinLHS) || tempLHS.contains(joinRHS)) {
			
			TCPFlag = true; 
			if(tempLHS.contains(joinLHS)) {
				////System.out.println("INSDE IF TCP");
				////System.out.println();
				int indexTCP = tempLHS.indexOf(joinLHS);
				LHS.add(joinRHS);
				RHS.add(tempRHS.get(indexTCP));
				operator.add("=");
				logical.add("AND");
				sqlarray.add("AND");
				sqlarray.add(joinRHS);
				sqlarray.add("=");
				sqlarray.add(tempRHS.get(indexTCP));
				
			} else {
				////System.out.println("INSDE ELSE TCP");
				int indexTCP = tempLHS.indexOf(joinRHS);
				LHS.add(joinLHS);
				RHS.add(tempRHS.get(indexTCP));
				operator.add("=");
				logical.add("AND");
				sqlarray.add("AND");
				sqlarray.add(joinLHS);
				sqlarray.add("=");
				sqlarray.add(tempRHS.get(indexTCP));
				
			}
		}
		////System.out.println("TCP FLAG!!!!!!!!!!!! " + TCPFlag);
		////System.out.println(tempLHS);
		////System.out.println(tempRHS);
		////System.out.println(sqlarray);
		////System.out.println(LHS);
		////System.out.println(RHS);
		////System.out.println(operator);
		////System.out.println(logical);
		/*
		 * Do TCP 
		 */
		boolean indexAvailableforT1 = false;
		boolean indexAvailableforT2 = false;
		int lhscolid = 99;
		int rhscolid = 99;
		for(Table t : table)
		for(Column c : t.getColumns() ) {
			if(c.getColName().trim().equalsIgnoreCase(lhs) && t.getTableName().equals(lhsTable)) {
				lhscolid = c.getColId();
				break;
			} else if(c.getColName().trim().equalsIgnoreCase(rhs) && t.getTableName().equals(rhsTable)) {
				rhscolid = c.getColId();
				break;
			}
		}
		String indexname = "";
		String tablnameforindex = "";
		boolean isMatchingT1 = false;
		boolean isMatchingT2 = false;
		boolean breakflag = false;
		String indexnameT1 = "";
		String indexnameT2 = "";
		////System.out.println(rhsTable + " CHK rhsTable") ;
		for(Table t: table) {
			//////System.out.println(t);
			indexname = "";
			////System.out.println(t.getTableName().equals(rhsTable));
			////System.out.println(t.getTableName() + " " + rhscolid + "TABLE LIST");
			for(Index i: t.getIndexes()) {
				for(Index.IndexKeyDef ikd : i.getIdxKey()) {
					if(ikd.colId == lhscolid && t.getTableName().equals(lhsTable)) {
						////System.out.println("IN LHS IF");
						indexAvailableforT1 = true;
						tablnameforindex = t.getTableName();
						if(ikd.idxColPos == 1)  {
							isMatchingT1 = true;
							indexnameT1 = i.getIdxName();
						} if(!isMatchingT1) {
							indexnameT1 = i.getIdxName();
						}
							
						//breakflag = true;
						break;
					} if (ikd.colId == rhscolid && t.getTableName().equalsIgnoreCase(rhsTable.trim())) {
						indexAvailableforT2 = true;
						if(ikd.idxColPos == 1) {
							isMatchingT2 = true;
							indexnameT2 = i.getIdxName();
						} if(!isMatchingT2) {
							indexnameT2 = i.getIdxName();
						}
						
						//indexnameT2 = i.getIdxName();
						tablnameforindex = t.getTableName();
						//breakflag = true;
						break;
					}
				}
			}
			//if(breakflag) break;
			////System.out.println("IN FOR: " + indexname);
		}
		determineLead(sqlarray, t1, table2, LHS, RHS);
		if(LHS.size() == 1) {
			//noindexnolocal(sqlarray,LHS.get(0),RHS.get(0));
			////System.out.println(indexAvailableforT1 + " T1");
			////System.out.println(indexAvailableforT2 + " T2");
			if(!indexAvailableforT1 && !indexAvailableforT2) {
				noindexnolocal(sqlarray,table,LHS,RHS, lhsTable,rhsTable);
			} else if((!indexAvailableforT1 && indexAvailableforT2) || (indexAvailableforT1 && !indexAvailableforT2)) {
				////System.out.println(indexname + " BEFORE CALLING");
				////System.out.println(indexAvailableforT1);
				////System.out.println(indexAvailableforT2);
				if(indexAvailableforT1)
					indexname = indexnameT1;
				else
					indexname = indexnameT2;
				indexnolocal(sqlarray,table, indexAvailableforT1 , indexAvailableforT2, LHS, RHS, lhsTable, rhsTable,indexname, tablnameforindex,isMatchingT1,isMatchingT2);
			} else if(indexAvailableforT1 && indexAvailableforT2){
				////System.out.println("IN 2 index call");
				////System.out.println(indexnameT1);
				////System.out.println(indexnameT2);
				////System.out.println(isMatchingT1);
				////System.out.println(isMatchingT2);
				if((isMatchingT1 && !isMatchingT2) || (!isMatchingT1 && isMatchingT2)) {
					
					/*
					 * 1 matching and 1 non matching
					 */
					ArrayList<String> columnList = new ArrayList<String> ();
					ArrayList<String> tblColList = new ArrayList<String> ();
					for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
						if(!sqlarray.get(i).equals(",")) {
							columnList.add(sqlarray.get(i).split("\\.")[1]);
							tblColList.add(sqlarray.get(i).split("\\.")[0]);
						}
					}
					
					//////System.out.println(columnList + " columnList");
					//////System.out.println(tblColList + " tblColList");
					
					lhs = LHS.get(0).split("\\.")[1];
					rhs = RHS.get(0).split("\\.")[1];
					boolean lfl = false;
					boolean rfl = false;
					int lhscc = 0; int rhscc = 0 ;
					//////System.out.println("inside rhs trim " + table.size());
					ArrayList<Integer> tc = new ArrayList<Integer> ();
					for(Table t : table) {
						//////System.out.println(t.getTableName());
						tc.add(t.getTableCard());
						for(Column c : t.getColumns() ) {
							//////System.out.println(c.getColName());
							if(t.getTableName().equals(lhsTable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
								//////System.out.println("INSIDE IF ");
								lhscc = c.getColCard();
								lfl = true;
								break;
							} if( t.getTableName().equals(rhsTable) &&c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
								//////System.out.println("inside rhs trim" + rhs);
								rhscc = c.getColCard();
								rfl = true;
								break;
							}
						}
					}
					Predicate p = new Predicate();
					p.setType('E');
					p.setCard1(lhscc);
					p.setCard2(rhscc);
					p.setFf1(1.0 / lhscc);
					p.setFf2(1.0 / rhscc);
					p.setSequence(1);
					StringBuffer sb = new StringBuffer();
					for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
						sb.append(sqlarray.get(i) + " ");
					}
					p.setText(sb.toString());
					ArrayList<Predicate> ap = new ArrayList<Predicate> ();
					ap.add(p);
					//new Predicate().printTable(new DbmsPrinter(), ap);
					PlanTable plan = new PlanTable();
					plan.accessType = 'I';
					
					//plan.matchCols
					////System.out.println("ACc here!!");
					if(isMatchingT1)
					plan.accessName = lhsTable.concat(indexnameT1);
					else
						plan.accessName = rhsTable.concat(indexnameT2);
					//plan.indexOnly
					plan.prefetch = ' ';
					plan.sortC_orderBy = 'N';
					
					plan.setTable1Card(table.get(0).getTableCard());
					plan.setTable2Card(table.get(1).getTableCard());
					ArrayList<String> selectList = new ArrayList<String> ();
					for(int i = 1 ; i < sqlarray.indexOf("FROM"); i++) {
						if(!sqlarray.get(i).trim().equals(","))
						selectList.add(sqlarray.get(i));
					}
					String leadtable = "";
					if(indexAvailableforT1) {
						//////System.out.println("LHS");
						//////System.out.println(LHS.get(0));
						leadtable = rhsTable;
						//lhs
					} else  {
						leadtable = lhsTable;
					} 
					if(isMatchingT1 || isMatchingT2)
						plan.matchCols = 1;
					plan.prefetch = 'S';
					plan.indexOnly = 'N';
					plan.setLeadTable(leadtable);
					this.planTable = plan;
					//plan.printTable(new DbmsPrinter());
					
					
					
					
					
					
					
				} else {
					//2 matching 
					/*
					 * decide on outer for 2 matching
					 */
					ArrayList<String> columnList = new ArrayList<String> ();
					ArrayList<String> tblColList = new ArrayList<String> ();
					for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
						if(!sqlarray.get(i).equals(",")) {
							columnList.add(sqlarray.get(i).split("\\.")[1]);
							tblColList.add(sqlarray.get(i).split("\\.")[0]);
						}
					}
					
					////System.out.println(columnList + " columnList");
					////System.out.println(tblColList + " tblColList");
					
					lhs = LHS.get(0).split("\\.")[1];
					rhs = RHS.get(0).split("\\.")[1];
					boolean lfl = false;
					boolean rfl = false;
					int lhscc = 0; int rhscc = 0 ;
					////System.out.println("inside rhs trim " + table.size());
					ArrayList<Integer> tc = new ArrayList<Integer> ();
					for(Table t : table) {
						////System.out.println(t.getTableName());
						tc.add(t.getTableCard());
						for(Column c : t.getColumns() ) {
							////System.out.println(c.getColName());
							if(t.getTableName().equals(lhsTable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
								////System.out.println("INSIDE IF ");
								lhscc = c.getColCard();
								lfl = true;
								break;
							} if( t.getTableName().equals(rhsTable) && c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
								////System.out.println("inside rhs trim" + rhs);
								rhscc = c.getColCard();
								rfl = true;
								break;
							}
						}
					}
					Predicate p = new Predicate();
					p.setType('E');
					p.setCard1(lhscc);
					p.setCard2(rhscc);
					p.setFf1(1.0 / lhscc);
					p.setFf2(1.0 / rhscc);
					p.setSequence(1);
					StringBuffer sb = new StringBuffer();
					for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
						sb.append(sqlarray.get(i) + " ");
					}
					p.setText(sb.toString());
					ArrayList<Predicate> ap = new ArrayList<Predicate> ();
					ap.add(p);
					//new Predicate().printTable(new DbmsPrinter(), ap);
					PlanTable plan = new PlanTable();
					plan.accessType = 'I';
					
					//plan.matchCols
					////System.out.println("ACc here!!");
					if(table.get(0).getTableCard() > table.get(1).getTableCard())
					plan.accessName = lhsTable.concat(indexnameT1);
					else
						plan.accessName = rhsTable.concat(indexnameT2);
					//plan.indexOnly
					plan.prefetch = ' ';
					plan.sortC_orderBy = 'N';
					
					plan.setTable1Card(table.get(0).getTableCard());
					plan.setTable2Card(table.get(1).getTableCard());
					ArrayList<String> selectList = new ArrayList<String> ();
					for(int i = 1 ; i < sqlarray.indexOf("FROM"); i++) {
						if(!sqlarray.get(i).trim().equals(","))
						selectList.add(sqlarray.get(i));
					}
					String leadtable = "";
					if(table.get(0).getTableCard() > table.get(1).getTableCard()) {
						////System.out.println("LHS");
						////System.out.println(LHS.get(0));
						leadtable = rhsTable;
						//lhs
					} else  {
						leadtable = lhsTable;
					} 
					if(isMatchingT1 || isMatchingT2)
						plan.matchCols = 1;
					plan.prefetch = 'S';
					plan.indexOnly = 'N';
					plan.setLeadTable(leadtable);
					//String ledT = determineLead(sqlarray, table.get(0), table.get(1), LHS, RHS);
					//plan.setLeadTable(ledT);
					this.planTable = plan;
					//plan.printTable(new DbmsPrinter());
					
				}
			}
		} else { //has local predicates
			if(!indexAvailableforT1 && !indexAvailableforT2) { //no index
				Table table1 = null;
				Table table2 = null;
				for(Table t: table) {
					if(t.getTableName().trim().equalsIgnoreCase(lhsTable.trim())) {
						table1 = t;
					} else if(t.getTableName().trim().equalsIgnoreCase(rhsTable.trim())) {
						table2 = t;
					} 
				}
				String leadingTable = determineLead(sqlarray,table1,table2,LHS,RHS);
				PlanTable pT = new PlanTable();
				pT.leadTable = leadingTable; //fill
				String ledT = determineLead(sqlarray, table.get(0), table.get(1), LHS, RHS);
				pT.setLeadTable(ledT);
				pT.accessType = 'R';
				pT.prefetch = 'S';
				pT.table1Card = table1.getTableCard();
				pT.table2Card = table2.getTableCard();
				this.planTable = pT;
				//pT.printTable(new DbmsPrinter());
			} else {
				//handle presence of index
				if((!indexAvailableforT1 && indexAvailableforT2) || (indexAvailableforT1 && !indexAvailableforT2)) {
					////System.out.println(indexname + " BEFORE CALLING");
					////System.out.println(indexAvailableforT1);
					////System.out.println(indexAvailableforT2);
					if(indexAvailableforT1)
						indexname = indexnameT1;
					else
						indexname = indexnameT2;
					indexnolocal(sqlarray,table, indexAvailableforT1 , indexAvailableforT2, LHS, RHS, lhsTable, rhsTable,indexname, tablnameforindex,isMatchingT1,isMatchingT2);
				} else if(indexAvailableforT1 && indexAvailableforT2){
					////System.out.println("IN 2 index call");
					////System.out.println(indexnameT1);
					////System.out.println(indexnameT2);
					////System.out.println(isMatchingT1);
					////System.out.println(isMatchingT2);
					if((isMatchingT1 && !isMatchingT2) || (!isMatchingT1 && isMatchingT2)) {
						
						/*
						 * 1 matching and 1 non matching
						 */
						ArrayList<String> columnList = new ArrayList<String> ();
						ArrayList<String> tblColList = new ArrayList<String> ();
						for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
							if(!sqlarray.get(i).equals(",")) {
								columnList.add(sqlarray.get(i).split("\\.")[1]);
								tblColList.add(sqlarray.get(i).split("\\.")[0]);
							}
						}
						
						////System.out.println(columnList + " columnList");
						////System.out.println(tblColList + " tblColList");
						
						lhs = LHS.get(0).split("\\.")[1];
						rhs = RHS.get(0).split("\\.")[1];
						boolean lfl = false;
						boolean rfl = false;
						int lhscc = 0; int rhscc = 0 ;
						////System.out.println("inside rhs trim " + table.size());
						ArrayList<Integer> tc = new ArrayList<Integer> ();
						for(Table t : table) {
							////System.out.println(t.getTableName());
							tc.add(t.getTableCard());
							for(Column c : t.getColumns() ) {
								////System.out.println(c.getColName());
								if(t.getTableName().equals(lhsTable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
									////System.out.println("INSIDE IF ");
									lhscc = c.getColCard();
									lfl = true;
									break;
								} if( t.getTableName().equals(rhsTable) &&c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
									////System.out.println("inside rhs trim" + rhs);
									rhscc = c.getColCard();
									rfl = true;
									break;
								}
							}
						}
						Predicate p = new Predicate();
						p.setType('E');
						p.setCard1(lhscc);
						p.setCard2(rhscc);
						p.setFf1(1.0 / lhscc);
						p.setFf2(1.0 / rhscc);
						p.setSequence(1);
						StringBuffer sb = new StringBuffer();
						for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
							sb.append(sqlarray.get(i) + " ");
						}
						p.setText(sb.toString());
						ArrayList<Predicate> ap = new ArrayList<Predicate> ();
						ap.add(p);
						//new Predicate().printTable(new DbmsPrinter(), ap);
						PlanTable plan = new PlanTable();
						plan.accessType = 'I';
						
						//plan.matchCols
						////System.out.println("ACc here!!");
						if(isMatchingT1)
						plan.accessName = lhsTable.concat(indexnameT1);
						else
							plan.accessName = rhsTable.concat(indexnameT2);
						//plan.indexOnly
						plan.prefetch = ' ';
						plan.sortC_orderBy = 'N';
						
						plan.setTable1Card(table.get(0).getTableCard());
						plan.setTable2Card(table.get(1).getTableCard());
						ArrayList<String> selectList = new ArrayList<String> ();
						for(int i = 1 ; i < sqlarray.indexOf("FROM"); i++) {
							if(!sqlarray.get(i).trim().equals(","))
							selectList.add(sqlarray.get(i));
						}
						String leadtable = "";
						if(indexAvailableforT1) {
							////System.out.println("LHS");
							////System.out.println(LHS.get(0));
							leadtable = rhsTable;
							//lhs
						} else  {
							leadtable = lhsTable;
						} 
						if(isMatchingT1 || isMatchingT2)
							plan.matchCols = 1;
						plan.prefetch = 'S';
						plan.indexOnly = 'N';
						String ledT = determineLead(sqlarray, table.get(0), table.get(1), LHS, RHS);
						plan.setLeadTable(ledT);
						//plan.setLeadTable(ledT);
						////System.out.println(tempLHS + " tempLHS");
						this.planTable = plan;
						//plan.printTable(new DbmsPrinter());
						
						
						
						
						
						
						
					} else {
						//2 matching 
						/*
						 * decide on outer for 2 matching
						 */
						ArrayList<String> columnList = new ArrayList<String> ();
						ArrayList<String> tblColList = new ArrayList<String> ();
						for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
							if(!sqlarray.get(i).equals(",")) {
								columnList.add(sqlarray.get(i).split("\\.")[1]);
								tblColList.add(sqlarray.get(i).split("\\.")[0]);
							}
						}
						
						////System.out.println(columnList + " columnList");
						////System.out.println(tblColList + " tblColList");
						
						lhs = LHS.get(0).split("\\.")[1];
						rhs = RHS.get(0).split("\\.")[1];
						boolean lfl = false;
						boolean rfl = false;
						int lhscc = 0; int rhscc = 0 ;
						////System.out.println("inside rhs trim " + table.size());
						ArrayList<Integer> tc = new ArrayList<Integer> ();
						for(Table t : table) {
							////System.out.println(t.getTableName());
							tc.add(t.getTableCard());
							for(Column c : t.getColumns() ) {
								////System.out.println(c.getColName());
								if(t.getTableName().equals(lhsTable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
									////System.out.println("INSIDE IF ");
									lhscc = c.getColCard();
									lfl = true;
									break;
								} if( t.getTableName().equals(rhsTable) && c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
									////System.out.println("inside rhs trim" + rhs);
									rhscc = c.getColCard();
									rfl = true;
									break;
								}
							}
						}
						Predicate p = new Predicate();
						p.setType('E');
						p.setCard1(lhscc);
						p.setCard2(rhscc);
						p.setFf1(1.0 / lhscc);
						p.setFf2(1.0 / rhscc);
						p.setSequence(1);
						StringBuffer sb = new StringBuffer();
						for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
							sb.append(sqlarray.get(i) + " ");
						}
						p.setText(sb.toString());
						ArrayList<Predicate> ap = new ArrayList<Predicate> ();
						ap.add(p);
						//new Predicate().printTable(new DbmsPrinter(), ap);
						PlanTable plan = new PlanTable();
						plan.accessType = 'I';
						
						//plan.matchCols
						////System.out.println("ACc here!!");
						if(table.get(0).getTableCard() > table.get(1).getTableCard())
						plan.accessName = lhsTable.concat(indexnameT1);
						else
							plan.accessName = rhsTable.concat(indexnameT2);
						//plan.indexOnly
						plan.prefetch = ' ';
						plan.sortC_orderBy = 'N';
						
						plan.setTable1Card(table.get(0).getTableCard());
						plan.setTable2Card(table.get(1).getTableCard());
						ArrayList<String> selectList = new ArrayList<String> ();
						for(int i = 1 ; i < sqlarray.indexOf("FROM"); i++) {
							if(!sqlarray.get(i).trim().equals(","))
							selectList.add(sqlarray.get(i));
						}
						String leadtable = "";
						if(table.get(0).getTableCard() > table.get(1).getTableCard()) {
							////System.out.println("LHS");
							////System.out.println(LHS.get(0));
							leadtable = rhsTable;
							//lhs
						} else  {
							leadtable = lhsTable;
						} 
						if(isMatchingT1 || isMatchingT2)
							plan.matchCols = 1;
						plan.prefetch = 'S';
						plan.indexOnly = 'N';
						////System.out.println("CALLING DETERMINE METHOD");
						////System.out.println(LHS);
						////System.out.println(RHS);
						////System.out.println(plan.accessName + " indexname");
						String ledT = determineLead(sqlarray, table.get(0), table.get(1), LHS, RHS);
						plan.setLeadTable(ledT);
						
						/*
						 * Checking matchcols
						 */
						////System.out.println(tempLHS + "tempLHS");
						this.planTable = plan;
						//plan.printTable(new DbmsPrinter());
						
					}
				}
			}
			
		}
		
		/*
		 * Update matchcols here..
		 */
		if(planTable.accessType == 'I') {
			Table tab = null;
			String leadingTable = planTable.leadTable;
			for(Table t : table ) {
				if(!t.getTableName().trim().equalsIgnoreCase(leadingTable.trim())) {
					tab = t;
					break;
				}
			}
			int tblLength = tab.getTableName().trim().length();
			
			String idxName = planTable.accessName.substring(tblLength);
			ArrayList<Integer> colsAvInIndex = new ArrayList<Integer> ();
			for(Index i : tab.getIndexes()) {
				if(i.getIdxName().trim().equalsIgnoreCase(idxName.trim())) {
					for(Index.IndexKeyDef ikd : i.getIdxKey()) {
						colsAvInIndex.add(ikd.colId);
					}
				}
			}
			ArrayList<Integer> predIn = new ArrayList<Integer>();
			ArrayList<String> tempLHSpred = new ArrayList<String> ();
			if(!remove) 
			for(int i = 0; i < LHS.size(); i++) {
				if(LHS.get(i).contains(".") && RHS.get(i).contains(".")) {
					continue;
				} if(LHS.get(i).startsWith(tab.getTableName().toUpperCase())) {
					tempLHSpred.add(LHS.get(i).substring(tblLength + 1));
				}
			}else {
				for(int i = 0; i < LHS.size() - 1; i++) {
					if(LHS.get(i).contains(".") && RHS.get(i).contains(".")) {
						continue;
					} if(LHS.get(i).startsWith(tab.getTableName().toUpperCase())) {
						tempLHSpred.add(LHS.get(i).substring(tblLength + 1));
					}
				}
			}
			 
			ArrayList<Integer> lhscols = new ArrayList<Integer> ();
			for(String s: tempLHSpred) {
				for(Column c: tab.getColumns()) {
					if(c.getColName().trim().equalsIgnoreCase(s.trim())) {
						lhscols.add(c.getColId());
					}
				}
			}
			for(int i: lhscols) {
				if(colsAvInIndex.contains(i)) {
					planTable.matchCols += 1;
				}
			}
			//////System.out.println(colsAvInIndex + " cols INDEX");
			//////System.out.println(lhscols + " lhs cols");
			//////System.out.println(tempLHSpred + " tempLHSpred");
			
		}
		//String test = "HELLO";
		//////System.out.println(test.substring(2));
		new Predicate().printTable(new DbmsPrinter(),classPredicates);
		return planTable;
		
	}
	/*
	 * Determines leading table based on FF
	 */
	
	private String determineLead (ArrayList<String> sqlarray, Table t1 ,Table table2, ArrayList<String> LHS, ArrayList<String> RHS) {
	//Stri	
		////System.out.println("IN LOCAL PRED METHOD");
		////System.out.println(LHS);
		////System.out.println(RHS);
		String joinPredicateLHS = "";
		String joinPredicateRHS = "";
		int joinindex = -1;
		for(int i = 0; i < RHS.size(); i++) {
			if(RHS.get(i).startsWith(table2.getTableName()+".") || (RHS.get(i).startsWith(t1.getTableName()+"."))) {
				joinPredicateLHS = LHS.get(i);
				joinPredicateRHS = RHS.get(i);
				if(RHS.get(i).startsWith(t1.getTableName()+".")) {
					Table temp = t1;
					t1 = table2;
					table2 = temp;
					
				}
				joinindex = i;
				break;
			}
		}
		ArrayList<Double> lhsff = new ArrayList<Double> ();
		ArrayList<Double> rhsff = new ArrayList<Double> ();
		////System.out.println(joinPredicateRHS.substring(joinPredicateRHS.indexOf('.')+1) + "ABV FOR");
		for(Column c: table2.getColumns()) {
			////System.out.println(c.getColName());
			////System.out.println(c.getColName().trim().equalsIgnoreCase(joinPredicateRHS.substring(joinPredicateRHS.indexOf('.')+1)));
			if(c.getColName().trim().equalsIgnoreCase(joinPredicateRHS.substring(joinPredicateRHS.indexOf('.')+1))) {
				////System.out.println("INSIDE IF");
				rhsff.add( 1.0 / new Double(c.getColCard()) );
			}
		}
		////System.out.println(t1.getTableName());
		////System.out.println(table2.getTableName());
		for (String s: LHS) {
			////System.out.println(s.substring(s.indexOf('.')+1));
			////System.out.println(s.substring(0,s.indexOf('.')-1));
			for(Column c : t1.getColumns()) {
				if(t1.getTableName().trim().equalsIgnoreCase(s.substring(0, s.indexOf('.'))) && c.getColName().trim().equalsIgnoreCase(s.substring(s.indexOf('.')+1).trim())) {
					lhsff.add( 1.0 / new Double(c.getColCard()));
				}
			} for(Column c: table2.getColumns()) {
				if(table2.getTableName().trim().equalsIgnoreCase(s.substring(0, s.indexOf('.'))) && c.getColName().trim().equalsIgnoreCase(s.substring(s.indexOf('.')+1).trim())) {
					rhsff.add(1.0 / new Double(c.getColCard()));
				}
			}
		}
		//leadingTable = 1;
		String leadingTable = "";
		lhsff.add(new Double(t1.getTableCard()));
		rhsff.add(new Double(table2.getTableCard()));
		double t1combinedff = 1.0;
		double t2combinedff = 1.0;
		for(double d: lhsff)
			t1combinedff *= d;
		for(double d: rhsff) 
			t2combinedff *= d;
		if(t1combinedff > t2combinedff) {
			leadingTable = t1.getTableName();
		} else {
			leadingTable = table2.getTableName();
		}
		////System.out.println(lhsff + " lhsff");
		////System.out.println(rhsff + " rhsff");
		ArrayList<Predicate> predicates = new ArrayList<Predicate> ();
		for(int i = 0; i < LHS.size(); i++) {
			Predicate predicate = new Predicate();
			predicate.type = 'E';
			predicate.setText(LHS.get(i) + " = " + RHS.get(i));
			Table t = null;
			if(LHS.get(i).substring(0, LHS.get(i).indexOf('.')).trim().equalsIgnoreCase(t1.getTableName())) {
				t = t1;
			} else {
				t = table2;
			}
			Column col = null;
			for(Column c : t.getColumns()) {
				if(c.getColName().trim().equalsIgnoreCase(LHS.get(i).substring(LHS.get(i).indexOf('.')+1))) {
					col = c;
				}
			}
			predicate.setCard1(col.getColCard());
			predicate.setFf1(1.0 / new Double(col.getColCard()));
			
			if(i == joinindex) {
				Column col1 = null;
				for(Column c : table2.getColumns()) {
					if(c.getColName().trim().equalsIgnoreCase(RHS.get(i).substring(RHS.get(i).indexOf('.')+1))) {
						col1 = c;
					}
				}
				predicate.setCard2(col1.getColCard());
				predicate.setFf2(1.0 / new Double(col1.getColCard()));
				
			}
					
			predicates.add(predicate);
		}
		//new Predicate().printTable(new DbmsPrinter(), predicates);
		////System.out.println(leadingTable);
		////System.out.println(joinindex);
		//Vigneshwari 
		//yourmethod(predicates,leadingTable)
		classPredicates = setSequence(predicates, leadingTable, LHS, RHS);
		
		return leadingTable;
	}
	private void indexnolocal(ArrayList<String> sqlarray, ArrayList<Table> table, boolean indexAvailableforT1, boolean indexAvailableforT2 , ArrayList<String> LHS, ArrayList<String> RHS, String lhstable , String rhstable, String indexName, String tablenameforindex, boolean isMatchingT1, boolean isMatchingT2) {
		// TODO Auto-generated method stub
		////System.out.println("INDEX NO LOCAL..");
		ArrayList<String> columnList = new ArrayList<String> ();
		ArrayList<String> tblColList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i).split("\\.")[1]);
				tblColList.add(sqlarray.get(i).split("\\.")[0]);
			}
		}
		
		////System.out.println(columnList + " columnList");
		////System.out.println(tblColList + " tblColList");
		
		String lhs = LHS.get(0).split("\\.")[1];
		String rhs = RHS.get(0).split("\\.")[1];
		boolean lfl = false;
		boolean rfl = false;
		int lhscc = 0; int rhscc = 0 ;
		////System.out.println("inside rhs trim " + table.size());
		ArrayList<Integer> tc = new ArrayList<Integer> ();
		for(Table t : table) {
			////System.out.println(t.getTableName());
			tc.add(t.getTableCard());
			for(Column c : t.getColumns() ) {
				////System.out.println(c.getColName());
				if(t.getTableName().equals(lhstable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
					////System.out.println("INSIDE IF ");
					lhscc = c.getColCard();
					lfl = true;
					break;
				} if( t.getTableName().equals(rhstable) &&c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
					////System.out.println("inside rhs trim" + rhs);
					rhscc = c.getColCard();
					rfl = true;
					break;
				}
			}
		}
		Predicate p = new Predicate();
		p.setType('E');
		p.setCard1(lhscc);
		p.setCard2(rhscc);
		p.setFf1(1.0 / lhscc);
		p.setFf2(1.0 / rhscc);
		p.setSequence(1);
		StringBuffer sb = new StringBuffer();
		for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
			sb.append(sqlarray.get(i) + " ");
		}
		p.setText(sb.toString());
		ArrayList<Predicate> ap = new ArrayList<Predicate> ();
		ap.add(p);
		//new Predicate().printTable(new DbmsPrinter(), ap);
		PlanTable plan = new PlanTable();
		plan.accessType = 'I';
		
		//plan.matchCols
		////System.out.println("ACc here!!");
		if(indexAvailableforT1)
		plan.accessName = lhstable.concat(indexName);
		else
			plan.accessName = rhstable.concat(indexName);
		//plan.indexOnly
		plan.prefetch = ' ';
		plan.sortC_orderBy = 'N';
		
		plan.setTable1Card(table.get(0).getTableCard());
		plan.setTable2Card(table.get(1).getTableCard());
		ArrayList<String> selectList = new ArrayList<String> ();
		for(int i = 1 ; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).trim().equals(","))
			selectList.add(sqlarray.get(i));
		}
		////System.out.println(selectList);
		Table tableI = null;
		if(indexAvailableforT1) {
			tableI = table.get(0);
		} else tableI = table.get(1);
		boolean indexOnlyFlag = false;
		int matchCols = 0;
		boolean matsel = false;
		ArrayList<Integer> selectcollistfromtable = new ArrayList<Integer> ();
		
		for(String s : selectList) {
			String tblname = s.substring(0, s.indexOf('.'));
			if(tblname.equalsIgnoreCase(tablenameforindex)) {
				matsel = true;
				for(Column c: tableI.getColumns()) {
					if(c.getColName().trim().equalsIgnoreCase(s.substring(s.indexOf('.')+1).trim())) {
						selectcollistfromtable.add(c.getColId());
					}
				}
			}
		}
		ArrayList<Integer> ikdI = new ArrayList<Integer> ();
		ArrayList<Integer> indexdef = new ArrayList<Integer> ();
		Table t = tableI;
		if(t.getTableName().trim().equalsIgnoreCase(tablenameforindex.trim())) {
			for(Index i : t.getIndexes()) {
				if(indexName.trim().equalsIgnoreCase(i.getIdxName())) {
					////System.out.println("Inside if");
					for(Index.IndexKeyDef ikd : i.getIdxKey()) {
						ikdI.add(ikd.colId);
						indexdef.add(ikd.idxColPos);
					}
				}
			}
		}
		boolean flag = true;
		for(int i : selectcollistfromtable) {
			if(!ikdI.contains(i)) {
				flag = false;
			}
		}
		if(matsel) {
		//for(Table t: table) {
			
			if(flag) {
				plan.indexOnly = 'Y';
			} else {
				plan.indexOnly = 'N';
			}
		//}
		} else {
			plan.indexOnly = 'N';
		}
		//////System.out.println(indexName);
		//////System.out.println(tableI.getTableName());
		//////System.out.println(tablenameforindex);
		//////System.out.println(ikdI + " ikdI");
		//////System.out.println(indexdef);
		String colname = "";
		String leadtable = "";
		if(indexAvailableforT1) {
			////System.out.println("LHS");
			////System.out.println(LHS.get(0));
			colname = LHS.get(0).substring(RHS.get(0).indexOf('.')+1).trim();
			leadtable = rhstable;
			//lhs
		} else  {
			////System.out.println("RHS");
			colname = RHS.get(0).substring(RHS.get(0).indexOf('.')+1).trim();
			leadtable = lhstable;
		} /*for(Column c: tableI.getColumns()) {
			if(colname.trim().equalsIgnoreCase(c.getColName())) {
				if(c.getColId() == ikdI.get(0)) {
					plan.matchCols = 1;
				}
			}
		}*/
		if(isMatchingT1 || isMatchingT2)
			plan.matchCols = 1;
		plan.prefetch = 'S';
		plan.indexOnly = 'N';
		plan.setLeadTable(leadtable);
		this.planTable = plan;
		//plan.printTable(new DbmsPrinter());
	}
	private void noindexnolocal(ArrayList<String> sqlarray , ArrayList<Table> table, ArrayList<String> LHS, ArrayList<String> RHS, String lhstable, String rhstable) {
		////System.out.println("NO INDEX NO LOCAL..");
		ArrayList<String> columnList = new ArrayList<String> ();
		ArrayList<String> tblColList = new ArrayList<String> ();
		for(int i = 1; i < sqlarray.indexOf("FROM"); i++) {
			if(!sqlarray.get(i).equals(",")) {
				columnList.add(sqlarray.get(i).split("\\.")[1]);
				tblColList.add(sqlarray.get(i).split("\\.")[0]);
			}
		}
		
		////System.out.println(columnList + " columnList");
		////System.out.println(tblColList + " tblColList");
		
		String lhs = LHS.get(0).split("\\.")[1];
		String rhs = RHS.get(0).split("\\.")[1];
		boolean lfl = false;
		boolean rfl = false;
		int lhscc = 0; int rhscc = 0 ;
		////System.out.println("inside rhs trim " + table.size());
		ArrayList<Integer> tc = new ArrayList<Integer> ();
		for(Table t : table) {
			////System.out.println(t.getTableName());
			tc.add(t.getTableCard());
		for(Column c : t.getColumns() ) {
			////System.out.println(c.getColName());
			if(t.getTableName().equals(lhstable) && c.getColName().trim().equalsIgnoreCase(lhs) && lfl == false) {
				////System.out.println("INSIDE IF ");
				lhscc = c.getColCard();
				lfl = true;
				break;
			} if( t.getTableName().equals(rhstable) &&c.getColName().trim().equalsIgnoreCase(rhs.trim()) && rfl == false) {
				////System.out.println("inside rhs trim" + rhs);
				rhscc = c.getColCard();
				rfl = true;
				break;
			}
		}
		}
		Predicate p = new Predicate();
		p.setType('E');
		p.setCard1(lhscc);
		p.setCard2(rhscc);
		p.setFf1(1.0 / lhscc);
		p.setFf2(1.0 / rhscc);
		p.setSequence(1);
		StringBuffer sb = new StringBuffer();
		for(int i = sqlarray.indexOf("WHERE") + 1 ; i < sqlarray.size(); i++) {
			sb.append(sqlarray.get(i) + " ");
		}
		p.setText(sb.toString());
		ArrayList<Predicate> ap = new ArrayList<Predicate> ();
		ap.add(p);
		//new Predicate().printTable(new DbmsPrinter(), ap);
		PlanTable plan = new PlanTable();
		plan.prefetch = 'S';
		plan.table1Card = tc.get(0);
		plan.table2Card = tc.get(1);
		if(tc.get(0) > tc.get(1)) {
			plan.leadTable = table.get(0).getTableName();
			
		} else {
			plan.leadTable = table.get(1).getTableName();
		}
		this.planTable = plan;
		//plan.printTable(new DbmsPrinter());
		
		
	}
	ArrayList<Predicate> AssignSeqNum(ArrayList<Predicate> predicates)
	{
		Map<Double, String> result = new HashMap<Double, String> ();
		for(Predicate p1 : predicates) {
			result.put(p1.getFf1(), p1.getText());
		}
		Map<Double,String> r = new TreeMap<Double,String> (result);
		
		ArrayList<Integer> seqval= new ArrayList<Integer>();
		ArrayList<String> labl = new ArrayList<String> ();
		int count = 1,indx = 0;
		
		for (Map.Entry<Double, String> entry : r.entrySet())
		{
			//System.out.println(entry.getKey() + "/" + entry.getValue());
			seqval.add(count++);
			labl.add(entry.getValue());
		}
		////System.out.println(seqval);
		//System.out.println(labl);
		int index1 = 0;
		for (String s : labl)
		for(Predicate pa : predicates) {
			if(s.equals(pa.getText())) {
				pa.setSequence(seqval.get(index1++));
				break;
			}
		}
		return predicates;
	}
	ArrayList<Predicate> setSequence(ArrayList<Predicate> predicates ,String leadTable,ArrayList<String> LHS,ArrayList<String> RHS)
	{
		//System.out.println("**************SetSequence******************");
		ArrayList<Predicate> leadTables=new ArrayList<Predicate>();
		ArrayList<Predicate> joinTables=new ArrayList<Predicate>();
		ArrayList<Predicate> secondaryTables=new ArrayList<Predicate>();
		int i= 0;
		for(Predicate predicate: predicates)
		{
			////System.out.println("LHS:"+LHS +"RHSTABLE:"+RHS);
			String lhsTable = LHS.get(i).substring(0, LHS.get(i).indexOf('.')).trim();
			//String rhsTable = RHS.get(i).substring(0, RHS.get(i).indexOf('.')).trim();
			////System.out.println("LHSTABLE:"+lhsTable);
			if(predicates.get(i).getFf2()!=0 && predicates.get(i).getFf1()!=0)
			{
				joinTables.add(predicate);
			}
			else if(lhsTable.equalsIgnoreCase(leadTable))
			{
				
					leadTables.add(predicate);
			}
			else 
			{
				secondaryTables.add(predicate);
			}
			i++;
		}
		//for(Predicate predicate: leadTables)
			////System.out.println("leadTables:"+predicate.getText());
		//for(Predicate predicate: joinTables)
		//	//System.out.println("joinTables:"+predicate.getText());
		//for(Predicate predicate: secondaryTables)
		//	//System.out.println("secondaryTables:"+predicate.getText());
		AssignSeqNum(leadTables);
		AssignSeqNum(joinTables);
		AssignSeqNum(secondaryTables);
		int maxSeq = 0;
		for(Predicate p: predicates)
		{
			for(Predicate q:leadTables)
			{
				if(p.getText().equalsIgnoreCase(q.getText()))
				{
					if(q.getSequence() != 0)
					{
						p.setSequence(q.getSequence());
						if(maxSeq < q.getSequence())
							maxSeq = q.getSequence();
					}
				}
			}
		}
		int maxSeqJoin  = 0;
		for(Predicate p: predicates)
		{
			for(Predicate q:joinTables)
			{
				if(p.getText().equalsIgnoreCase(q.getText()))
				{
					if(q.getSequence() != 0)
					{
						p.setSequence(q.getSequence()+maxSeq);
						if(maxSeqJoin < p.getSequence())
							maxSeqJoin = p.getSequence();
					}
				}
			}
		}
		for(Predicate p: predicates)
		{
			for(Predicate q:secondaryTables)
			{
				if(p.getText().equalsIgnoreCase(q.getText()))
				{
					if(q.getSequence() != 0)
					{
						p.setSequence(q.getSequence()+maxSeqJoin);
					}
				}
			}
		}
		i = 0;
		if(TCPFlag)
			predicates.get(predicates.size()-1).setDescription("TCP");
		for(Predicate p:predicates)
		{
			if(p.getDescription().equalsIgnoreCase("TCP"))
			{
				
				String lhsTable = LHS.get(i).substring(0, LHS.get(i).indexOf('.')).trim();
				////System.out.println(lhsTable + " " + leadTable + " " + i);
				if(!lhsTable.equalsIgnoreCase(leadTable)) {
					p.setSequence(0);
					remove = true;
				}
				
				
			}
			i++;
		}
		//arrange seq properly just in case if index is modified in TCP above
		ArrayList<Integer> seqval = new ArrayList<Integer>();
		for(Predicate pa : predicates) 
		{
			if(pa.getSequence() != 0)
				seqval.add(pa.getSequence());
			
		}
		Collections.sort(seqval);
		////System.out.println("-------------------seqval in ascending order------");
		//for(int pa : seqval) 
		{
			////System.out.println(seqval);	
			
		}
		int j = 1;
		i = 0;
		for(int p : seqval)
		{
			i = p;
			for(Predicate pa : predicates)
			{
				if(pa.getSequence() == i)
				{
					pa.setSequence(j);
					
				}
			}	
			j++;
			//i++;
		}
		//new Predicate().printTable(new DbmsPrinter(), predicates);
		return predicates;
		
	}
}
